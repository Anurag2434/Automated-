#!/usr/bin/env bash
# Run the full automated test suite.
#
#   scripts/run_tests.sh [pattern]
#
# Renders are included (Tests 1-6); expect ~1-3 minutes on a small machine.
set -euo pipefail
cd "$(dirname "$0")/.."

PATTERN="${1:-}"
if [[ -n "$PATTERN" ]]; then
  exec python3 -m unittest discover -s tests -p "test_*.py" -v -k "$PATTERN"
else
  exec python3 -m unittest discover -s tests -p "test_*.py" -v
fi
