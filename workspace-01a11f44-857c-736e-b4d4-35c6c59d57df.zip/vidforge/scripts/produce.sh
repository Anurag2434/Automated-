#!/usr/bin/env bash
# End-to-end production command.
#
#   scripts/produce.sh <config.json> [output_dir]
#
# Runs the full pipeline: read config -> validate -> check assets -> build
# scene plan -> render scenes -> assemble -> burn text -> mix audio -> export
# MP4 -> verify -> write report. Exits non-zero on any failure.
set -euo pipefail
cd "$(dirname "$0")/.."

CONFIG="${1:-examples/documentary_30s.json}"
OUT="${2:-}"

if [[ $# -gt 0 ]]; then
  exec python3 -m vidforge render "$CONFIG" ${OUT:+--out "$OUT"}
else
  echo "usage: scripts/produce.sh <config.json> [output_dir]"
  echo "example configs:"
  ls examples/*.json | sed 's/^/  /'
  exit 2
fi
