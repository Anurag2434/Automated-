# vidforge — lightweight, AI-optional video production pipeline

`vidforge` turns a JSON project description into a verified MP4 using
Python 3 (standard library only) + FFmpeg. It supports two workflows that
share components but keep their production requirements separate:

| | **Workflow A — anime_reel** | **Workflow B — documentary** |
|---|---|---|
| Orientation | vertical 9:16 (default 720x1280) | landscape 16:9 (default 1280x720) |
| Duration | 5–90 s (presets 15/30/45/60) | 5–3600 s (presets up to 60 min) |
| Signature feature | beat-synced cuts (half-beat grid), beat-pulse effect, punchy captions, vivid styles | chapter/scene structure, narration track, title cards, subtitle sidecars, muted styles |
| Output | H.264 + AAC MP4, faststart, `.srt` sidecar | same |

Everything renders **without any AI or network access**: scenes can use your
own images/videos, or clearly-watermarked **synthetic test graphics** so the
pipeline can always be exercised end-to-end.

---

## Quick start

```bash
# 1) system dependency: ffmpeg (any full build with libx264 + AAC).
#    Optional: pip install imageio-ffmpeg   (bundles a static ffmpeg)
#    Or drop a static binary at ./bin/ffmpeg

# 2) end-to-end render of the bundled examples (Tests 1 & 2)
python3 -m vidforge demo

#    or a single project
scripts/produce.sh examples/documentary_30s.json out/my_doc
python3 -m vidforge render examples/anime_reel_15s.json --out out/my_reel

# 3) run the automated test suite (renders included, ~1-2 min)
scripts/run_tests.sh
```

Each render produces in its output directory:

- `<name>.mp4` — the video (H.264/AAC, web-optimized faststart)
- `<name>.srt` — subtitle sidecar (upload with the video on YouTube/Instagram)
- `report.md` / `report.json` — what was rendered, verification results, warnings, honesty notes
- `timeline.html` — self-contained visual scene timeline

## Commands

```
python3 -m vidforge render   <config.json> [--out DIR] [--keep-temp] [--strict] [--dry-run]
python3 -m vidforge validate <config.json> [--strict]
python3 -m vidforge plan     <config.json> [--json]        # scene plan, no render
python3 -m vidforge draft    <anime_reel|documentary> "<topic>" --duration S [--ai]
python3 -m vidforge probe    <media-file>
python3 -m vidforge caps                                    # environment capability report
python3 -m vidforge demo
```

`render --dry-run` validates the config, checks all assets, and builds the
scene plan without rendering anything (useful for 30–60 min projects).

## Project configuration

See `examples/` for complete working configs. Core schema:

```jsonc
{
  "project": {
    "name": "my_project",          // required-ish (defaults to filename)
    "type": "anime_reel",          // or "documentary"          [required]
    "duration": 15,                // seconds, type-bounded      [required]
    "resolution": [720, 1280],     // even numbers; defaults per type
    "fps": 30,                     // 10-60
    "language": "en",              // narration/subtitle language (BCP-47)
    "assets_dir": "assets"         // where relative source paths resolve
  },
  "render": { "crf": 26, "preset": "veryfast",
              "transition_duration": 0.5, "fade_out": 0.8 },
  "style": { "preset": "vivid",              // clean | vivid | muted | noir | retro
             "palette": ["#ff2d78", ...],    // synthetic gradients + accents
             "beat_pulse": true },
  "audio": {
    "enabled": true,
    "beat_sync": true,                       // reels default true, docs false
    "music": {
      "source": "synthetic",                 // "synthetic" | "none" | path/to/audio
      "bpm": 128,                            // omit to auto-estimate from file
      "volume_db": -10, "fade_in": 0.5, "fade_out": 1.2
    },
    "narration": { "enabled": true, "language": "en",
                   "volume_db": 0, "dir": "narration" }   // <dir>/<scene_id>.wav
  },
  "subtitles": { "enabled": true, "burn": true,
                 "font_size": 34, "position": "lower_third" },  // bottom|lower_third|top
  "scenes": [
    {
      "id": "hook",                    // unique
      "title": "HOOK",                 // small label; "TITLE: X" = big title card
      "duration": 3.0,                 // or null -> auto-distribute
      "source": "synthetic",           // "synthetic" | image path | video path
      "visual": "gradient",            // gradient | flat (synthetic look)
      "subtitle": "caption text",      // burned + written to .srt
      "narration": "spoken text",      // subtitle fallback; audio via files/TTS
      "transition_in": "cut",          // cut|fade|fadewhite|dissolve|wipeleft|wiperight|
                                       // slideleft|slideright|circleopen|circleclose|pixelize
      "effect": "beat_pulse"           // zoom|shake|grain|mirror|beat_pulse
    }
  ]
}
```

**Duration rules.** Scenes with explicit durations must sum to
`project.duration` (±0.05 s). Scenes with `duration: null` share the
remaining time. All durations are quantized to whole frames; for reels with
beat sync on, interior cuts are snapped to the half-beat grid.

**Transitions.** `cut`/`fade`/`fadewhite` are per-clip; the rest are
crossfades applied between scene groups (they consume
`render.transition_duration` of overlap, so the final timeline is slightly
shorter than the sum of scene durations — reported in `report.md`).

**Media handling.** Images are cover-cropped to the target frame;
`effect: "zoom"` adds a Ken Burns push. Videos are trimmed to the scene
duration, or **looped** (with a warning) when too short. Every scene whose
source is `synthetic` renders a generated gradient and carries a permanent
**"SYNTHETIC TEST FOOTAGE"** watermark.

## Narration audio

Per-scene files are picked up from `<narration.dir>/<scene_id>.<wav|mp3|...>`
when `audio.narration.enabled` is true, and mixed at each scene's timeline
offset with music (independent dB controls, music fades). Missing files
produce a **warning in the report**, not a silent failure. TTS is an AI
provider capability (below) — not required for rendering.

## AI integration (optional, off by default)

Providers implement `vidforge/ai/base.py::AIProvider`
(`generate_script`, `generate_narration_audio`, `generate_image`,
`generate_video`). Nothing in the render pipeline calls them; they are used
only by explicit commands.

- `null` (default) — always raises with instructions; guarantees offline use.
- `openai_compat` — any OpenAI-compatible REST endpoint (OpenAI, OpenRouter,
  LM Studio, vLLM). Enable with `OPENAI_API_KEY` (+ optional
  `OPENAI_BASE_URL`, `OPENAI_MODEL`); keys are never printed. Requests are
  bounded (`max_tokens`, 60 s timeout). Script drafting:
  `python3 -m vidforge draft documentary "topic" --duration 180 --ai`.
  Image generation is implemented but **untested** (no key in this
  environment); video generation raises `AICapabilityError` by design.
- `offline` — `vidforge draft` without `--ai` scaffolds a config from a
  deterministic template (zero network, zero cost).

Adding a provider = one class + one line in `vidforge/ai/__init__.py`
`get_provider()`. No renderer changes.

## Testing

`scripts/run_tests.sh` runs 77 tests (~90 s here), including full renders:

- Test 1 — 15 s vertical 9:16 anime reel (synthetic) rendered & verified
- Test 2 — 30 s landscape documentary (synthetic) rendered & verified
- Test 3 — 45 s documentary rendered (duration is config-driven, not fixed)
- Test 4 — 15-min and 60-min documentary plans validated **without rendering**
- Test 5 — missing assets / invalid configs produce actionable errors
- Test 6 — sample audio file mixed into video; explicit mux + verify test
- Plus: BPM estimation vs. known-tempo click tracks, beat-grid alignment,
  real image (Ken Burns) / real video (loop) sources, ASS-injection safety,
  verifier true-negatives.

See `TEST_REPORT.md` for actual results from this environment.

## Project layout

```
vidforge/            Python package (stdlib only)
  config.py          load + validate project JSON
  scenes.py          frame-exact plans, beat snapping, transition grouping
  assets.py          source resolution + pre-flight checks
  render.py          scene render -> assembly (concat/xfade) -> burn -> mux
  audio.py           BPM estimation, music/narration mixing
  subtitles.py       SRT sidecars + ASS overlay generation
  synth.py           synthetic music/click/tone generation (pure Python)
  validation.py      output verification (probe + full decode)
  report.py          report.md / report.json / timeline.html
  env.py             ffmpeg discovery, capability detection, media probing
  ai/                provider interface + null/openai_compat/offline
examples/            anime reel, documentary (30 s, 45 s, 15-min plan), template
tests/               unittest suite (renders included)
scripts/             produce.sh (end-to-end), run_tests.sh
```

## Honesty guarantees

- Synthetic scenes are watermarked **in the video itself**, and every report
  states in plain words what is synthetic.
- AI is never called implicitly; reports state when it was not used.
- Narration/TTS that was not actually mixed is listed in report warnings.
- The verifier re-opens and fully decodes every output before declaring PASS.
