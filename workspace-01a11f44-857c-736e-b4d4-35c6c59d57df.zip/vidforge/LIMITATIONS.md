# Known limitations

## Rendering engine

- **Crossfades shorten the timeline.** `dissolve`/wipe/slide transitions
  consume `render.transition_duration` of overlap between scenes, so a
  15 s project with one 0.4 s dissolve exports ~14.6 s. This is standard
  NLE behaviour and is reported in `report.md` (`final_total_seconds`), but
  if you need *exactly* 15.000 s, use cut/fade transitions or add the
  overlap back into the last scene's duration.
- **Beat grid is frame-quantized.** A 128 BPM grid at 30 fps is 7.03 frames
  per half-beat; cuts land within one frame of the true grid.
- **BPM estimation is heuristic.** Onset-envelope autocorrelation with a
  120-BPM octave preference. Verified within ±3 BPM on synthetic click
  tracks and music beds (60–160 BPM). Ambiguous material (rubato, sparse
  ambient, half-time grooves) can be off by an octave — set `music.bpm`
  explicitly when you know it. Explicit BPM always wins.
- **Per-scene re-encode.** Scenes are encoded, then concatenated (`-c copy`
  where possible), then overlays are burned with one more full re-encode.
  Two encode generations is fine for prototypes/social; add
  `--keep-temp` + a lossless intermediate if you need a mastering path.
- **Long projects**: plan validation is tested up to 60 minutes, but actual
  renders above ~10 minutes were **not** executed in the sandbox (time and
  storage budget). Expect roughly linear render time (~2x realtime observed
  on 2 vCPU).
- One audio track: music + narration mixed to stereo AAC. No multi-track
  stems, no spatial audio, no loudness normalization (EBU R128) yet.

## Assets

- No asset *search or download* — you provide files or use synthetic
  placeholders. No copyright clearance is performed; that responsibility
  stays with you.
- Videos shorter than their scene are **looped** (with a warning) rather
  than slowed or extended intelligently.
- `effect: "zoom"` (Ken Burns) applies to image sources only; on videos it
  is ignored with a warning.
- Frame-accurate seeking of source videos starts at 0 only (`-ss` trimming
  of source clips is not exposed yet).

## Text / subtitles

- All burned text uses DejaVu Sans via libass/fontconfig. Font choice is
  not configurable yet (single style set: caption, title, label, watermark).
- CJK/non-Latin text should work (Noto CJK fonts were present here) but was
  **not** exercised by the test suite.
- Subtitle timing is proportional to cue length within a scene — no
  word-level timing, no karaoke.

## AI integration

- The AI layer is interface + provider stubs. In this environment **no
  credentials existed**, so no AI call of any kind was made or tested.
  `openai_compat.generate_script` is implemented but untested;
  `generate_image` is implemented but untested; `generate_narration_audio`
  and `generate_video` intentionally raise `AICapabilityError` — they are
  documented extension points.
- No AI video generation anywhere. Nothing claims to generate anime footage;
  reel scenes are placeholders for your own clips.

## Environment-specific notes (this sandbox)

- FFmpeg was not preinstalled; it was bootstrapped via
  `pip install imageio-ffmpeg` (static 7.0.2 build, GPLv3). That binary
  lives in site-packages, which is **not** part of the persisted workspace
  snapshot — rerun `pip install imageio-ffmpeg` (or install a system ffmpeg)
  in a fresh session before rendering.
- That build lacks `drawtext`; text rendering goes through libass `subtitles`
  instead (this is handled automatically and is arguably better).
- 2 vCPU / ~2 GB RAM: 15–45 s renders took 16–36 s each.

## Not implemented (extension points)

- `scene.audio_cue` (sound effects per scene) — validated as a warning.
- Word-level/lyric caption timing.
- EBU R128 loudness normalization and true-peak limiting.
- Multi-language subtitle tracks (one SRT per render).
- Source clip trim windows (`-ss`/`-to` per scene).
- Preview/playback server; `timeline.html` is static only.
