"""TEST 5: missing assets and invalid configs produce useful errors.
Also: output verification behaviour and the explicit audio-mux case."""

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vidforge import env, synth, validation
from vidforge.assets import AssetError, resolve_source
from vidforge.config import ConfigError, load_config
from vidforge.render import render_project
from helpers import EXAMPLES, SKIP_NO_FFMPEG


class TestMissingAssets(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)

    def _write(self, cfg, name="p.json"):
        p = self.dir / name
        p.write_text(json.dumps(cfg))
        return p

    def test_missing_scene_source_error_lists_path_and_scene(self):
        p = self._write({
            "project": {"type": "documentary", "duration": 10,
                        "resolution": [640, 360], "fps": 30},
            "scenes": [
                {"id": "ok_scene", "duration": 5, "source": "synthetic"},
                {"id": "broken_scene", "duration": 5,
                 "source": "assets/does_not_exist.mp4"},
            ],
        })
        result = render_project(p, out_dir=self.dir / "out", quiet=True)
        self.assertFalse(result.ok)
        self.assertEqual(len(result.errors), 1)
        err = result.errors[0]
        self.assertIn("broken_scene", err)
        self.assertIn("does_not_exist.mp4", err)
        self.assertIn("not found", err)
        self.assertIn("Tried", err)  # shows the searched locations
        # nothing should have been rendered
        self.assertFalse((self.dir / "out" / "real.mp4").exists())

    def test_missing_music_file_error(self):
        p = self._write({
            "project": {"type": "documentary", "duration": 10,
                        "resolution": [640, 360], "fps": 30},
            "audio": {"enabled": True,
                      "music": {"source": "music/missing_song.mp3"}},
            "scenes": [{"id": "a", "source": "synthetic"}],
        })
        result = render_project(p, out_dir=self.dir / "out", quiet=True)
        self.assertFalse(result.ok)
        self.assertIn("missing_song.mp3", result.errors[0])

    def test_unsupported_extension_error(self):
        p = self._write({
            "project": {"type": "documentary", "duration": 10,
                        "resolution": [640, 360], "fps": 30},
            "scenes": [{"id": "a", "source": "assets/photo.gif"}],
        })
        (self.dir / "assets").mkdir()
        (self.dir / "assets" / "photo.gif").write_bytes(b"GIF89a")
        result = render_project(p, out_dir=self.dir / "out", quiet=True)
        self.assertFalse(result.ok)
        self.assertIn("unsupported extension", result.errors[0])

    def test_invalid_config_rejected_before_render(self):
        p = self._write({
            "project": {"type": "documentary", "duration": 10,
                        "resolution": [640, 360], "fps": 30},
            "scenes": [
                {"id": "a", "duration": 4, "source": "synthetic"},
                {"id": "b", "duration": 4, "source": "synthetic"},  # 8 != 10
            ],
        })
        result = render_project(p, out_dir=self.dir / "out", quiet=True)
        self.assertFalse(result.ok)
        self.assertIn("sum to", result.errors[0])
        self.assertIn("Config error", result.errors[0])

    def test_nonexistent_config_clear_error(self):
        result = render_project("/nowhere/x.json", quiet=True)
        self.assertFalse(result.ok)
        self.assertIn("not found", result.errors[0])


class TestAssetResolution(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)

    def _cfg(self, source, assets_dir="assets"):
        p = self.dir / "p.json"
        p.write_text(json.dumps({
            "project": {"type": "documentary", "duration": 10,
                        "resolution": [640, 360], "fps": 30,
                        "assets_dir": assets_dir},
            "scenes": [{"id": "a", "source": source}],
        }))
        return load_config(p)

    def test_synthetic_variants(self):
        for src, label in (("synthetic", "synthetic"),
                           ("synthetic:flashback", "flashback")):
            cfg = self._cfg(src)
            spec = resolve_source(src, cfg)
            self.assertEqual(spec.kind, "synthetic")
            self.assertEqual(spec.label, label)

    def test_missing_error_lists_all_searched_paths(self):
        cfg = self._cfg("clips/hero.mp4")
        with self.assertRaises(AssetError) as cm:
            resolve_source("clips/hero.mp4", cfg)
        msg = str(cm.exception)
        self.assertIn("clips/hero.mp4", msg)
        self.assertIn("assets/clips/hero.mp4", msg)  # assets_dir fallback tried

    def test_image_and_video_classification(self):
        (self.dir / "assets").mkdir()
        (self.dir / "assets" / "x.jpg").write_bytes(b"jpg")
        (self.dir / "assets" / "y.mp4").write_bytes(b"mp4")
        cfg = self._cfg("assets/x.jpg")
        self.assertEqual(resolve_source("assets/x.jpg", cfg).kind, "image")
        self.assertEqual(resolve_source("assets/y.mp4", cfg).kind, "video")


@SKIP_NO_FFMPEG
class TestExplicitAudioMux(unittest.TestCase):
    """TEST 6 (standalone): mux a small sample audio file with a rendered
    video and verify the result."""

    def test_tone_muxed_with_rendered_video(self):
        caps = env.get_caps()
        import subprocess, tempfile
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            # 1) tiny video
            v = td / "v.mp4"
            subprocess.run([caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                            "-f", "lavfi", "-t", "2",
                            "-i", "color=c=navy:s=320x240:r=30",
                            "-c:v", "libx264", "-preset", "ultrafast",
                            "-pix_fmt", "yuv420p", str(v)], check=True)
            # 2) small sample audio file (clearly synthetic)
            a = synth.synth_tone(td / "sample.wav", 2.0, freq=660)
            self.assertLess(a.stat().st_size, 400_000)  # it is small
            # 3) mux
            out = td / "muxed.mp4"
            subprocess.run([caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                            "-i", str(v), "-i", str(a),
                            "-map", "0:v", "-map", "1:a",
                            "-c:v", "copy", "-c:a", "aac", "-b:a", "128k",
                            "-shortest", str(out)], check=True)
            # 4) verify with the project's own verification module
            res = validation.verify_output(out, expected_duration=2.0,
                                           width=320, height=240, fps=30,
                                           expect_audio=True,
                                           duration_tolerance=0.3, caps=caps)
            self.assertTrue(res.ok, msg=str(res.failures))


@SKIP_NO_FFMPEG
class TestVerifyOutputBehaviour(unittest.TestCase):
    """The verifier must actually fail when expectations are wrong."""

    @classmethod
    def setUpClass(cls):
        cls.caps = env.get_caps()
        import tempfile
        cls.tmp = tempfile.TemporaryDirectory()
        cls.dir = Path(cls.tmp.name)
        cls.clip = cls.dir / "c.mp4"
        import subprocess
        subprocess.run([cls.caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                        "-f", "lavfi", "-t", "3",
                        "-i", "color=c=red:s=320x240:r=24",
                        "-c:v", "libx264", "-preset", "ultrafast",
                        "-pix_fmt", "yuv420p", str(cls.clip)], check=True)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_correct_expectations_pass(self):
        res = validation.verify_output(self.clip, expected_duration=3.0,
                                       width=320, height=240, fps=24,
                                       expect_audio=False, caps=self.caps)
        self.assertTrue(res.ok, msg=str(res.failures))

    def test_wrong_duration_fails(self):
        res = validation.verify_output(self.clip, expected_duration=9.0,
                                       duration_tolerance=0.3, caps=self.caps)
        self.assertFalse(res.ok)
        self.assertTrue(any(c.name == "duration" and not c.ok
                            for c in res.checks))

    def test_wrong_resolution_fails(self):
        res = validation.verify_output(self.clip, width=999, height=999,
                                       caps=self.caps)
        self.assertFalse(res.ok)

    def test_missing_audio_fails_when_expected(self):
        res = validation.verify_output(self.clip, expect_audio=True,
                                       caps=self.caps)
        self.assertFalse(res.ok)
        self.assertTrue(any(c.name == "audio" and not c.ok
                            for c in res.checks))

    def test_nonexistent_file_fails_cleanly(self):
        res = validation.verify_output(self.dir / "nope.mp4")
        self.assertFalse(res.ok)
        self.assertEqual(res.checks[0].name, "exists")


if __name__ == "__main__":
    unittest.main()
