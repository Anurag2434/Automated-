"""Unit tests: project configuration loading and validation."""

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vidforge.config import ConfigError, load_config
from helpers import EXAMPLES


def write_cfg(data, tmpdir, name="test.json"):
    p = Path(tmpdir) / name
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


def base_cfg(**overrides):
    cfg = {
        "project": {
            "name": "t", "type": "documentary", "duration": 30,
            "resolution": [640, 360], "fps": 30,
        },
        "scenes": [
            {"id": "a", "duration": 10, "source": "synthetic"},
            {"id": "b", "duration": 10, "source": "synthetic"},
            {"id": "c", "duration": 10, "source": "synthetic"},
        ],
    }
    for k, v in overrides.items():
        if k == "project":
            cfg["project"].update(v)
        else:
            cfg[k] = v
    return cfg


class TestExampleConfigs(unittest.TestCase):
    def test_examples_load_cleanly(self):
        for name in ("anime_reel_15s.json", "documentary_30s.json",
                     "documentary_45s.json", "documentary_15min_plan.json"):
            with self.subTest(example=name):
                cfg = load_config(EXAMPLES / name)
                self.assertGreater(len(cfg.scenes), 0)
                # example configs should be warning-free
                self.assertEqual(cfg.warnings, [], f"unexpected warnings: {cfg.warnings}")

    def test_file_assets_example_is_flagged_as_template(self):
        # it references files that (deliberately) do not exist; it must still parse
        p = EXAMPLES / "documentary_file_assets.example.json"
        cfg = load_config(p)
        self.assertEqual(cfg.project.type, "documentary")
        self.assertIn("music", str(cfg.music.source))


class TestConfigValidation(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def test_missing_file(self):
        with self.assertRaises(ConfigError) as cm:
            load_config("/nonexistent/nope.json")
        self.assertIn("not found", str(cm.exception))

    def test_invalid_json(self):
        p = Path(self.tmp.name) / "bad.json"
        p.write_text("{not json")
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("not valid JSON", str(cm.exception))

    def test_bad_project_type(self):
        p = write_cfg(base_cfg(project={"type": "music_video"}), self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("project.type", str(cm.exception))

    def test_documentary_duration_bounds(self):
        # over the 3600s bound
        p = write_cfg(base_cfg(project={"duration": 4000}), self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("out of bounds", str(cm.exception))

    def test_anime_reel_duration_bounds(self):
        cfg = base_cfg(project={"type": "anime_reel", "duration": 120,
                                "resolution": [720, 1280]})
        cfg["scenes"] = [{"id": "a", "source": "synthetic"}]
        p = write_cfg(cfg, self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("out of bounds", str(cm.exception))

    def test_scene_sum_mismatch(self):
        cfg = base_cfg()
        cfg["scenes"][2]["duration"] = 5  # 10+10+5 != 30
        p = write_cfg(cfg, self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("sum to", str(cm.exception))
        self.assertIn("auto-distribute", str(cm.exception))

    def test_scene_sum_exceeds_total(self):
        cfg = base_cfg()
        cfg["scenes"][0]["duration"] = 25
        p = write_cfg(cfg, self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("exceeds", str(cm.exception))

    def test_odd_resolution_rejected(self):
        p = write_cfg(base_cfg(project={"resolution": [641, 361]}), self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("even", str(cm.exception))

    def test_bad_transition(self):
        cfg = base_cfg()
        cfg["scenes"][1]["transition_in"] = "star_wipe"
        p = write_cfg(cfg, self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("transition_in", str(cm.exception))
        self.assertIn("star_wipe", str(cm.exception))

    def test_duplicate_scene_ids(self):
        cfg = base_cfg()
        cfg["scenes"][1]["id"] = "a"
        p = write_cfg(cfg, self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("Duplicate scene id", str(cm.exception))

    def test_unknown_keys_warn_and_strict_fails(self):
        cfg = base_cfg()
        cfg["frobnicate"] = True
        cfg["scenes"][0]["wat"] = 1
        p = write_cfg(cfg, self.tmp.name)
        c = load_config(p)
        self.assertTrue(any("frobnicate" in w for w in c.warnings))
        self.assertTrue(any("scenes[0].wat" in w for w in c.warnings))
        with self.assertRaises(ConfigError):
            load_config(p, strict=True)

    def test_auto_distribute_too_little_time(self):
        cfg = base_cfg()
        cfg["scenes"] = [
            {"id": "a", "duration": 29.8, "source": "synthetic"},
            {"id": "b", "duration": None, "source": "synthetic"},
        ]
        p = write_cfg(cfg, self.tmp.name)
        with self.assertRaises(ConfigError) as cm:
            load_config(p)
        self.assertIn("Not enough time", str(cm.exception))

    def test_defaults_by_type(self):
        p = write_cfg({
            "project": {"type": "anime_reel", "duration": 15},
            "scenes": [{"id": "a", "source": "synthetic"}],
        }, self.tmp.name)
        cfg = load_config(p)
        self.assertEqual((cfg.project.width, cfg.project.height), (720, 1280))
        self.assertEqual(cfg.project.fps, 30)
        self.assertTrue(cfg.beat_sync)  # reels default to beat sync on

        p2 = write_cfg({
            "project": {"type": "documentary", "duration": 15},
            "scenes": [{"id": "a", "source": "synthetic"}],
        }, self.tmp.name, "doc.json")
        cfg2 = load_config(p2)
        self.assertEqual((cfg2.project.width, cfg2.project.height), (1280, 720))
        self.assertFalse(cfg2.beat_sync)


if __name__ == "__main__":
    unittest.main()
