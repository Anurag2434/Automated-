"""Shared test helpers and constants."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

EXAMPLES = ROOT / "examples"
OUT = ROOT / "out"


def has_ffmpeg() -> bool:
    try:
        from vidforge import env
        env.get_caps()
        return True
    except Exception:
        return False


FFMPEG_AVAILABLE = has_ffmpeg()
SKIP_NO_FFMPEG = unittest.skipUnless(
    FFMPEG_AVAILABLE, "ffmpeg not available in this environment"
)
