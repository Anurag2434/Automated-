"""Unit tests: synthetic audio generation, BPM estimation, audio mix."""

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vidforge import env, synth
from vidforge.audio import build_audio_track, estimate_bpm
from vidforge.config import load_config
from vidforge.scenes import build_plan
from helpers import SKIP_NO_FFMPEG, EXAMPLES


class TestSynthGeneration(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)

    def test_music_bed_file(self):
        p = synth.synth_music_bed(self.dir / "bed.wav", 3.0, bpm=120)
        self.assertTrue(p.is_file())
        import wave
        with wave.open(str(p)) as w:
            self.assertEqual(w.getframerate(), 44100)
            self.assertEqual(w.getnchannels(), 2)
            dur = w.getnframes() / w.getframerate()
        self.assertAlmostEqual(dur, 3.0, delta=0.05)

    def test_click_track_file(self):
        p = synth.synth_click_track(self.dir / "click.wav", 4.0, bpm=100)
        self.assertTrue(p.is_file())
        self.assertGreater(p.stat().st_size, 44100 * 2)


@SKIP_NO_FFMPEG
class TestBPMEstimation(unittest.TestCase):
    """Beat detection is validated against generated click tracks with known
    tempos (no third-party audio libraries involved)."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.caps = env.get_caps()

    def _estimate(self, bpm, duration=20.0):
        p = synth.synth_click_track(self.dir / f"click_{bpm}.wav", duration, bpm)
        return estimate_bpm(str(p), self.caps)

    def test_128_bpm(self):
        got = self._estimate(128)
        self.assertAlmostEqual(got, 128, delta=2.5,
                               msg=f"estimated {got} for a 128 BPM click")

    def test_96_bpm(self):
        got = self._estimate(96)
        self.assertAlmostEqual(got, 96, delta=2.5,
                               msg=f"estimated {got} for a 96 BPM click")

    def test_160_bpm(self):
        got = self._estimate(160)
        self.assertAlmostEqual(got, 160, delta=3.0,
                               msg=f"estimated {got} for a 160 BPM click")

    def test_music_bed_tempo_is_detectable(self):
        bed = synth.synth_music_bed(self.dir / "bed.wav", 20.0, bpm=120)
        got = estimate_bpm(str(bed), self.caps)
        self.assertAlmostEqual(got, 120, delta=3.0,
                               msg=f"estimated {got} for synthetic 120 BPM bed")


@SKIP_NO_FFMPEG
class TestAudioMix(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.caps = env.get_caps()

    def _cfg(self, name="doc.json"):
        import shutil
        dst = self.dir / name
        shutil.copy(EXAMPLES / "documentary_30s.json", dst)
        return load_config(dst)

    def test_music_only_mix(self):
        cfg = self._cfg()
        plan = build_plan(cfg, bpm=90)
        res = build_audio_track(cfg, plan, self.dir, self.caps)
        self.assertIsNotNone(res.path)
        self.assertTrue(res.used_music)
        self.assertEqual(res.narration_clips, [])  # no narration files exist
        info = env.probe_media(str(res.path), self.caps)
        self.assertAlmostEqual(info["duration"], plan.final_total, delta=0.3)
        self.assertTrue(info["has_audio"])

    def test_mix_with_narration_files(self):
        cfg = self._cfg()
        narr_dir = self.dir / "narration"
        narr_dir.mkdir()
        # one tone file per narrated scene, clearly synthetic
        for sc_id in ("cold_open", "context", "turning_point", "closing"):
            synth.synth_tone(narr_dir / f"{sc_id}.wav", 2.0, freq=550)
        plan = build_plan(cfg, bpm=90)
        res = build_audio_track(cfg, plan, self.dir, self.caps)
        self.assertIsNotNone(res.path)
        self.assertEqual(len(res.narration_clips), 4)
        info = env.probe_media(str(res.path), self.caps)
        self.assertTrue(info["has_audio"])
        self.assertAlmostEqual(info["duration"], plan.final_total, delta=0.3)

    def test_no_audio_when_disabled(self):
        import json
        data = json.loads((EXAMPLES / "documentary_30s.json").read_text())
        data["audio"]["enabled"] = False
        data["audio"]["music"]["source"] = "none"
        p = self.dir / "silent.json"
        p.write_text(json.dumps(data))
        cfg = load_config(p)
        plan = build_plan(cfg, bpm=None)
        res = build_audio_track(cfg, plan, self.dir, self.caps)
        self.assertIsNone(res.path)
        self.assertFalse(res.used_music)


if __name__ == "__main__":
    unittest.main()
