"""TEST 2: 30-second synthetic landscape documentary render, verified.
TEST 3: documentary duration is configurable (45s render, not 3/4 minutes).
TEST 6: a small sample audio file (synthetic music) is combined with the
video and the mixed result is verified (audio stream + full decode).
"""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vidforge.render import render_project
from helpers import EXAMPLES, OUT, SKIP_NO_FFMPEG


def _check(result, name):
    return [c for c in result.verify.checks if c.name == name][0]


@SKIP_NO_FFMPEG
class TestDocumentary30s(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.out = OUT / "documentary_30s"
        cls.result = render_project(EXAMPLES / "documentary_30s.json",
                                    out_dir=cls.out, quiet=True)
        if not cls.result.ok and cls.result.plan is None:
            raise unittest.SkipTest(f"render failed before planning: {cls.result.errors}")

    def test_render_succeeded(self):
        self.assertTrue(self.result.ok, msg=str(self.result.errors))

    def test_landscape_resolution(self):
        res = _check(self.result, "resolution")
        self.assertTrue(res.ok, res.detail)
        self.assertGreater(self.result.plan.width, self.result.plan.height)

    def test_duration_near_30s(self):
        self.assertAlmostEqual(self.result.plan.final_total, 30.0, delta=0.8)
        dur = _check(self.result, "duration")
        self.assertTrue(dur.ok, dur.detail)

    def test_music_mixed_in(self):
        """TEST 6 (via the pipeline): the sample audio file is combined with
        the video; output must carry an audio stream and decode cleanly."""
        audio = _check(self.result, "audio")
        self.assertTrue(audio.ok, audio.detail)
        self.assertTrue(self.result.audio_report["music"])
        dec = _check(self.result, "decodable")
        self.assertTrue(dec.ok, dec.detail)

    def test_narration_missing_warning_is_reported(self):
        self.assertTrue(any("no audio file found" in w.lower()
                            for w in self.result.warnings))

    def test_subtitles_burned_and_sidecar(self):
        self.assertTrue(self.result.srt_path.is_file())
        # captions burned -> overlay stage produced events
        report = (self.out / "report.md").read_text()
        self.assertIn("subtitle? |", report)  # scene table rendered


@SKIP_NO_FFMPEG
class TestDocumentary45s(unittest.TestCase):
    """TEST 3: prove the documentary duration is config-driven, not fixed."""

    @classmethod
    def setUpClass(cls):
        cls.out = OUT / "documentary_45s"
        cls.result = render_project(EXAMPLES / "documentary_45s.json",
                                    out_dir=cls.out, quiet=True)
        if not cls.result.ok and cls.result.plan is None:
            raise unittest.SkipTest(f"render failed before planning: {cls.result.errors}")

    def test_render_succeeded(self):
        self.assertTrue(self.result.ok, msg=str(self.result.errors))

    def test_duration_is_45s_not_a_default(self):
        # neither 30s nor the 'classic' 180/240s documentary defaults
        self.assertAlmostEqual(self.result.plan.final_total, 45.0, delta=1.5)
        self.assertNotAlmostEqual(self.result.plan.final_total, 30.0, delta=5.0)
        self.assertNotAlmostEqual(self.result.plan.final_total, 180.0, delta=5.0)
        dur = _check(self.result, "duration")
        self.assertTrue(dur.ok, dur.detail)


if __name__ == "__main__":
    unittest.main()
