"""TEST 1: 15-second synthetic vertical anime_reel render, verified."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vidforge.render import render_project
from helpers import EXAMPLES, OUT, SKIP_NO_FFMPEG


@SKIP_NO_FFMPEG
class TestAnimeReelRender(unittest.TestCase):
    """End-to-end render of the bundled 15s 9:16 example."""

    @classmethod
    def setUpClass(cls):
        cls.out = OUT / "anime_reel_15s"
        cls.result = render_project(EXAMPLES / "anime_reel_15s.json",
                                    out_dir=cls.out, quiet=True)
        if not cls.result.ok and cls.result.plan is None:
            raise unittest.SkipTest(f"render failed before planning: {cls.result.errors}")

    def test_render_succeeded(self):
        self.assertTrue(self.result.ok, msg=str(self.result.errors))

    def test_output_exists(self):
        self.assertTrue(self.result.output_path.is_file())
        self.assertGreater(self.result.output_path.stat().st_size, 100_000)

    def test_vertical_resolution(self):
        info_w = [c for c in self.result.verify.checks if c.name == "resolution"][0]
        self.assertTrue(info_w.ok, info_w.detail)
        self.assertLess(self.result.plan.width, self.result.plan.height)  # 9:16

    def test_duration_is_15s(self):
        # xfade overlaps shorten the final timeline slightly (documented
        # behaviour); it must still be within half a second of 15s.
        self.assertAlmostEqual(self.result.plan.final_total, 15.0, delta=0.6)
        dur = [c for c in self.result.verify.checks if c.name == "duration"][0]
        self.assertTrue(dur.ok, dur.detail)

    def test_beat_synced_plan(self):
        self.assertEqual(self.result.plan.bpm, 128)
        self.assertIsNotNone(self.result.plan.beat_grid)
        self.assertTrue(any("Beat snap" in n for n in self.result.plan.notes))

    def test_audio_track_present(self):
        audio = [c for c in self.result.verify.checks if c.name == "audio"][0]
        self.assertTrue(audio.ok, audio.detail)

    def test_decodable(self):
        dec = [c for c in self.result.verify.checks if c.name == "decodable"][0]
        self.assertTrue(dec.ok, dec.detail)

    def test_srt_sidecar(self):
        self.assertTrue(self.result.srt_path.is_file())
        content = self.result.srt_path.read_text()
        self.assertIn("-->", content)

    def test_honesty_notes_in_report(self):
        report = (self.out / "report.md").read_text()
        self.assertIn("SYNTHETIC TEST GRAPHICS", report)
        self.assertIn("synthetic placeholder", report)


if __name__ == "__main__":
    unittest.main()
