"""Unit tests: scene planning (durations, beat grid, 15-min plan)."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vidforge.config import load_config
from vidforge.scenes import MIN_SCENE_FRAMES, build_plan
from helpers import EXAMPLES


def make_cfg(tmpdir, ptype="anime_reel", duration=15, scenes=None, **audio):
    import json
    data = {
        "project": {"type": ptype, "duration": duration, "fps": 30,
                    "resolution": [720, 1280] if ptype == "anime_reel" else [640, 360]},
        "audio": audio or {},
        "scenes": scenes or [{"id": f"s{i}", "source": "synthetic"}
                             for i in range(4)],
    }
    p = Path(tmpdir) / "cfg.json"
    p.write_text(json.dumps(data))
    return load_config(p)


class TestDurationPlanning(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def test_frame_exact_totals(self):
        for duration in (15, 30, 45, 90, 183.7):
            cfg = make_cfg(self.tmp.name, "documentary", duration)
            plan = build_plan(cfg, bpm=None)
            self.assertEqual(plan.total_frames, round(duration * 30))
            self.assertEqual(sum(s.frames for s in plan.scenes), plan.total_frames)
            self.assertAlmostEqual(plan.total, duration, places=3)

    def test_mixed_explicit_and_auto_durations(self):
        cfg = make_cfg(self.tmp.name, "documentary", 30, scenes=[
            {"id": "a", "duration": 10, "source": "synthetic"},
            {"id": "b", "source": "synthetic"},          # auto
            {"id": "c", "duration": 6, "source": "synthetic"},
            {"id": "d", "source": "synthetic"},          # auto
        ])
        plan = build_plan(cfg)
        self.assertEqual(sum(s.frames for s in plan.scenes), 900)
        # 14s left for b+d -> 7s each
        b, d = plan.scene_by_id("b"), plan.scene_by_id("d")
        self.assertAlmostEqual(b.duration, 7.0, places=2)
        self.assertAlmostEqual(d.duration, 7.0, places=2)

    def test_starts_are_monotonic(self):
        cfg = make_cfg(self.tmp.name, "documentary", 30)
        plan = build_plan(cfg)
        prev_end = 0.0
        for s in plan.scenes:
            self.assertAlmostEqual(s.start, prev_end, places=4)
            prev_end = s.start + s.duration
        self.assertAlmostEqual(prev_end, plan.total, places=4)


class TestBeatAlignment(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def test_cuts_snap_to_half_beat_grid(self):
        cfg = make_cfg(self.tmp.name, "anime_reel", 15,
                       scenes=[{"id": f"s{i}", "source": "synthetic"}
                               for i in range(6)],
                       beat_sync=True,
                       music={"source": "synthetic", "bpm": 128})
        plan = build_plan(cfg, bpm=128)
        half = 60 / 128 / 2
        grid = round(half * 30)  # frame-quantized half-beat grid
        acc = 0
        for s in plan.scenes[:-1]:
            acc += s.frames
            # every interior cut sits on (approximately) a half-beat multiple
            self.assertLess(abs(acc % grid), 2.0,
                            f"cut after {s.id} at frame {acc} not on grid {grid}")
            self.assertGreater(s.frames, 0)
        self.assertEqual(sum(s.frames for s in plan.scenes), plan.total_frames)

    def test_beat_sync_off_keeps_user_durations(self):
        cfg = make_cfg(self.tmp.name, "anime_reel", 15,
                       scenes=[{"id": "a", "duration": 7.3, "source": "synthetic"},
                               {"id": "b", "duration": 7.7, "source": "synthetic"}],
                       beat_sync=False,
                       music={"source": "synthetic", "bpm": 128})
        plan = build_plan(cfg, bpm=128)
        self.assertAlmostEqual(plan.scenes[0].duration, 7.3, places=2)
        self.assertAlmostEqual(plan.scenes[1].duration, 7.7, places=2)
        self.assertIsNone(plan.beat_grid)


class TestLongFormPlans(unittest.TestCase):
    """TEST 4: a 15-minute (and 60-minute) plan validates WITHOUT rendering."""

    def test_15_minute_documentary_plan(self):
        cfg = load_config(EXAMPLES / "documentary_15min_plan.json")
        plan = build_plan(cfg, bpm=cfg.music.bpm)
        self.assertEqual(len(plan.scenes), 13)
        self.assertEqual(plan.total_frames, 27000)
        self.assertAlmostEqual(plan.total, 900.0, places=3)
        # 6 dissolve boundaries x 0.8s (24 frames, capped at 40% of neighbours)
        expected_overlap = sum(b["frames"] for b in plan.xfade_boundaries)
        self.assertEqual(plan.final_total_frames, 27000 - expected_overlap)
        self.assertAlmostEqual(
            plan.final_total, 27000 / 30 - expected_overlap / 30, places=3
        )
        # final starts remain strictly increasing and inside the timeline
        prev = -1.0
        for s in plan.scenes:
            self.assertGreater(s.final_start, prev)
            self.assertLess(s.final_start, plan.final_total)
            prev = s.final_start
        # sanity: per-scene durations are chapter-scale, not reel-scale
        self.assertGreater(max(s.duration for s in plan.scenes), 30.0)

    def test_60_minute_documentary_plan(self):
        from vidforge.ai.offline import draft_project_offline
        import json, tempfile
        draft = draft_project_offline("documentary", "Deep Time", 3600)
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "d.json"
            p.write_text(json.dumps(draft))
            cfg = load_config(p)
        plan = build_plan(cfg)
        self.assertEqual(plan.total_frames, 108000)
        self.assertAlmostEqual(plan.total, 3600.0, places=3)


class TestTransitionGrouping(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)

    def test_segments_and_boundaries(self):
        cfg = make_cfg(self.tmp.name, "documentary", 30, scenes=[
            {"id": "a", "source": "synthetic"},
            {"id": "b", "source": "synthetic", "transition_in": "dissolve"},
            {"id": "c", "source": "synthetic"},
            {"id": "d", "source": "synthetic", "transition_in": "fade"},
            {"id": "e", "source": "synthetic", "transition_in": "wipeleft"},
        ])
        plan = build_plan(cfg)
        # xfade boundaries: after b (dissolve), after d (wipeleft)
        self.assertEqual(len(plan.xfade_boundaries), 2)
        self.assertEqual(len(plan.segments), 3)
        self.assertEqual([b["name"] for b in plan.xfade_boundaries],
                         ["fade", "wipeleft"])
        # segment 1 = a,b ; 2 = c,d ; 3 = e
        self.assertEqual((plan.segments[0].start_index, plan.segments[0].end_index), (0, 0))
        self.assertEqual((plan.segments[1].start_index, plan.segments[1].end_index), (1, 3))
        self.assertEqual((plan.segments[2].start_index, plan.segments[2].end_index), (4, 4))
        # final total is shorter by the overlaps
        self.assertEqual(
            plan.final_total_frames,
            plan.total_frames - sum(b["frames"] for b in plan.xfade_boundaries),
        )


if __name__ == "__main__":
    unittest.main()
