"""AI provider interface, offline drafting, and subtitle generation units."""

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vidforge import subtitles as sub
from vidforge.ai import (AICapabilityError, AIDisabledError, NullProvider,
                         draft_project_offline, get_provider)
from vidforge.config import load_config


class TestAIProviders(unittest.TestCase):
    def test_null_provider_is_default_and_raises_helpfully(self):
        p = get_provider("")
        self.assertIsInstance(p, NullProvider)
        caps = p.capabilities()
        self.assertFalse(any(caps.values()))
        with self.assertRaises(AIDisabledError) as cm:
            p.generate_script("brief", 30, "documentary")
        self.assertIn("AI is disabled", str(cm.exception))

    def test_unknown_provider_name(self):
        with self.assertRaises(ValueError):
            get_provider("skynet")

    def test_openai_compat_without_key_raises(self):
        import os
        had = os.environ.pop("OPENAI_API_KEY", None)  # never print it
        try:
            with self.assertRaises(AIDisabledError):
                get_provider("openai_compat")
        finally:
            if had:
                os.environ["OPENAI_API_KEY"] = had

    def test_base_provider_capability_errors(self):
        from vidforge.ai.base import AIProvider

        class Bare(AIProvider):
            pass

        b = Bare()
        with self.assertRaises(AICapabilityError):
            b.generate_image("prompt", "out.png")
        with self.assertRaises(AICapabilityError):
            b.generate_video("prompt", "out.mp4")
        with self.assertRaises(AICapabilityError):
            b.generate_narration_audio("text", "out.wav")


class TestOfflineDraft(unittest.TestCase):
    def test_reel_draft_is_a_valid_config(self):
        draft = draft_project_offline("anime_reel", "sunset duel", 15)
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "draft.json"
            p.write_text(json.dumps(draft))
            cfg = load_config(p)
        self.assertEqual(cfg.project.type, "anime_reel")
        self.assertEqual(cfg.project.duration, 15)
        self.assertTrue(cfg.beat_sync)

    def test_documentary_draft_is_a_valid_config(self):
        for duration in (15, 45, 90, 180, 240, 900, 1800, 2700, 3600):
            with self.subTest(duration=duration):
                draft = draft_project_offline("documentary", "topic", duration)
                with tempfile.TemporaryDirectory() as td:
                    p = Path(td) / "draft.json"
                    p.write_text(json.dumps(draft))
                    cfg = load_config(p)
                self.assertEqual(cfg.project.duration, duration)

    def test_draft_marks_template_content(self):
        draft = draft_project_offline("documentary", "topic", 60)
        texts = " ".join(s.get("narration", "") + s.get("subtitle", "")
                         for s in draft["scenes"])
        self.assertIn("TEMPLATE", texts)


class TestSubtitles(unittest.TestCase):
    def test_chunking_respects_limits(self):
        text = " ".join(f"word{i}" for i in range(30))
        chunks = sub.chunk_text(text)
        self.assertGreater(len(chunks), 1)
        for c in chunks:
            self.assertLessEqual(len(c), 42 * 2)

    def test_wrapping_two_lines_max(self):
        text = "This is a fairly long caption that should wrap onto two display lines"
        wrapped = sub.wrap_lines(text)
        self.assertLessEqual(wrapped.count("\\N"), 1)

    def test_srt_format(self):
        import tempfile
        cues = [sub.Cue(0.0, 2.5, "Hello world"), sub.Cue(2.5, 5.0, "Second cue")]
        with tempfile.TemporaryDirectory() as td:
            p = sub.write_srt(cues, Path(td) / "t.srt")
            content = p.read_text()
        self.assertIn("00:00:00,000 --> 00:00:02,500", content)
        self.assertIn("00:00:02,500 --> 00:00:05,000", content)
        self.assertEqual(content.count("Hello world"), 1)

    def test_ass_time_format(self):
        self.assertEqual(sub._ass_time(61.239), "0:01:01.24")

    def test_ass_escaping_blocks_injection(self):
        events = [sub.Cue(0, 1, "{\\an8}evil {\\pos(1,1)}")]
        with tempfile.TemporaryDirectory() as td:
            p = sub.write_ass(events, Path(td) / "t.ass", 640, 360)
            content = p.read_text()
        self.assertNotIn("\\pos", content)
        self.assertIn("(an8)evil", content)


if __name__ == "__main__":
    unittest.main()
