"""Real (non-synthetic) source coverage: a generated image with Ken Burns
zoom, a generated video clip (trimmed and looped), and a real music file are
rendered through the same pipeline as user-provided assets would be."""

import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from vidforge import env, synth
from vidforge.render import render_project
from helpers import SKIP_NO_FFMPEG


def _make_png(path: Path, size=(800, 500)):
    from PIL import Image, ImageDraw
    img = Image.new("RGB", size, (24, 60, 110))
    d = ImageDraw.Draw(img)
    for x in range(0, size[0], 50):
        d.line([(x, 0), (x, size[1])], fill=(240, 240, 240), width=2)
    d.rectangle([size[0] // 3, size[1] // 3, 2 * size[0] // 3, 2 * size[1] // 3],
                fill=(255, 180, 40))
    img.save(path)
    return path


def _make_video(path: Path, seconds: float, caps):
    import subprocess
    cmd = [caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
           "-f", "lavfi", "-t", f"{seconds}",
           "-i", f"testsrc2=s=640x360:r=30",
           "-c:v", "libx264", "-preset", "ultrafast", "-crf", "30",
           "-pix_fmt", "yuv420p", str(path)]
    subprocess.run(cmd, check=True, capture_output=True)
    return path


@SKIP_NO_FFMPEG
class TestRealAssetRender(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)

    def _build_project(self, scene_specs, music="synthetic"):
        caps = env.get_caps()
        assets = self.dir / "assets"
        assets.mkdir(exist_ok=True)
        _make_png(assets / "photo.png")
        _make_video(assets / "clip.mp4", 2.0, caps)   # shorter than scene -> loops
        music_path = synth.synth_music_bed(self.dir / "music.wav", 20.0, bpm=100)
        cfg = {
            "project": {"name": "real_assets_test", "type": "documentary",
                        "duration": 10, "resolution": [640, 360], "fps": 30,
                        "assets_dir": "assets"},
            "render": {"crf": 30, "preset": "ultrafast"},
            "audio": {
                "enabled": True,
                "music": {"source": str(music_path) if music != "synthetic"
                          else "synthetic", "bpm": 100, "volume_db": -14,
                          "fade_in": 0.5, "fade_out": 0.5},
                "narration": {"enabled": False},
            },
            "subtitles": {"enabled": True, "burn": True, "position": "bottom"},
            "scenes": scene_specs,
        }
        p = self.dir / "project.json"
        p.write_text(json.dumps(cfg))
        return p

    def test_image_zoom_video_loop_and_real_music(self):
        p = self._build_project([
            {"id": "img_scene", "duration": 4, "source": "assets/photo.png",
             "effect": "zoom", "subtitle": "Ken Burns zoom on a real image",
             "transition_in": "cut"},
            {"id": "vid_scene", "duration": 6, "source": "assets/clip.mp4",
             "subtitle": "short clip looped to fill the scene",
             "transition_in": "dissolve"},
        ], music="file")
        result = render_project(p, out_dir=self.dir / "out", quiet=True)
        self.assertTrue(result.ok, msg=str(result.errors))
        self.assertTrue(result.output_path.is_file())
        # looping note expected for the 2s clip in a 6s scene
        self.assertTrue(any("looping" in w for w in result.warnings),
                        msg=f"warnings: {result.warnings}")
        # real music file was mixed
        self.assertIn("file:music.wav", str(result.audio_report["music"]))
        # only non-synthetic scenes: no synthetic watermark note
        n_synth = sum(1 for s in result.plan.scenes if s.source == "synthetic")
        self.assertEqual(n_synth, 0)
        report = (self.dir / "out" / "report.md").read_text()
        self.assertIn("assets/photo.png", report)

    def test_ken_burns_output_resolution_matches_target(self):
        p = self._build_project([
            {"id": "img_scene", "duration": 5, "source": "assets/photo.png",
             "effect": "zoom", "transition_in": "cut"},
            {"id": "b", "duration": 5, "source": "assets/clip.mp4",
             "transition_in": "cut"},
        ])
        result = render_project(p, out_dir=self.dir / "out2", quiet=True)
        self.assertTrue(result.ok, msg=str(result.errors))
        res = [c for c in result.verify.checks if c.name == "resolution"][0]
        self.assertTrue(res.ok, res.detail)  # zoompan preserved 640x360


if __name__ == "__main__":
    unittest.main()
