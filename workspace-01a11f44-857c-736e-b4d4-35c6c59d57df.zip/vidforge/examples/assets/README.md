# Assets directory

Put your source media here (or reference paths relative to the config file).

## Supported per scene `source`

| kind   | extensions                       | notes                              |
|--------|----------------------------------|------------------------------------|
| image  | .jpg .jpeg .png .webp .bmp       | cover-cropped; `effect: zoom` adds a Ken Burns pan |
| video  | .mp4 .mov .mkv .webm .m4v .avi   | trimmed or looped to scene duration |
| synthetic | `synthetic` / `synthetic:<label>` | generated gradient placeholder, watermarked "SYNTHETIC TEST FOOTAGE" |

## Other audio assets

- `music.source`: path to an audio file (`.wav .mp3 .m4a .ogg .flac .aac .opus`).
- Narration: one file per scene at `narration/<scene_id>.wav` (or .mp3, ...),
  used when `audio.narration.enabled` is `true`.

## Licensing

Only use clips, images, and music you have the rights to:

- Your own footage and renders.
- Public-domain / Creative Commons material (check the license allows reuse).
- Properly licensed stock.
- AI-generated assets under the provider's terms.

The bundled examples deliberately use **only synthetic placeholders** —
vidforge never downloads copyrighted anime, music, or footage for you.
