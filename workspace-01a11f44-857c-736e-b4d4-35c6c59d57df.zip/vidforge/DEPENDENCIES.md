# Dependencies

## Python (runtime)

**None beyond the standard library** (`json`, `dataclasses`, `subprocess`,
`wave`, `array`, `unittest`, ...). Tested on Python 3.13; any Python >= 3.9
should work (no 3.10+ syntax used in the package).

`requirements.txt` is intentionally empty — see the note inside it.

Optional Python packages (auto-detected, never required):

| package | used for | when |
|---------|----------|------|
| `imageio-ffmpeg` | ships a static FFmpeg binary when the system has none | sandbox bootstrap / quick start |
| `Pillow` | only used by the *test suite* to generate a sample PNG and inspect frames | tests only |

## System

| tool | required? | notes |
|------|-----------|-------|
| **FFmpeg** (with libx264 or libopenh264, AAC or MP3 encoder) | required for rendering | any recent full build (4.x/5.x/6.x/7.x). Discovery order: `$VIDFORGE_FFMPEG` → `PATH` → `./bin/ffmpeg` → `imageio-ffmpeg` wheel |
| **ffprobe** | optional | if absent, `vidforge` falls back to parsing `ffmpeg -i` stderr (duration/resolution/fps/codec checks all still work) |
| fonts (e.g. DejaVu Sans) | required for burned text | any fontconfig-visible sans font; DejaVu ships on most Linux distros |
| libass in ffmpeg | required for burned text | standard in distro and static builds; the pipeline degrades to SRT-only with a warning if missing |
| `drawtext` filter | **not required** | this build path does not use it; text goes through libass instead |

## Not used (deliberately)

- No Docker, no n8n, no orchestration frameworks.
- No numpy/PIL/requests in the core package.
- No Remotion/Node (the FFmpeg path is lighter and was fully available).
- No ML models downloaded; no model weights stored.
