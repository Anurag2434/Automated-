# TEST REPORT — vidforge prototype

- **Date:** 2026-10-09 (UTC)
- **Environment:** Debian 13 "trixie", x86_64, 2 vCPU, ~1.9 GB RAM, 21 GB free disk
- **Suite:** `scripts/run_tests.sh` → `python3 -m unittest discover -s tests`
- **Final result: 77 tests, 77 passed, 0 failed, 0 skipped — 85.6 s wall time**
  (renders included; ~1.5× realtime on 2 vCPU)

---

## 1. What was found in the sandbox

| Check | Finding |
|---|---|
| OS / arch | Debian GNU/Linux 13 (trixie), x86_64, kernel 6.1 |
| CPU / RAM | 2 cores, 1.9 GiB RAM, no swap |
| Disk | 25 GB volume, 21 GB free (task budget of 128 MB respected regardless: final project = **4.8 MB**, 84 files) |
| Python | 3.13.16 (numpy, Pillow, requests present — **not used** by the core package) |
| Node.js | v20.20.2 (not needed; FFmpeg path chosen instead of Remotion) |
| **FFmpeg** | **not installed** → bootstrapped via `pip install imageio-ffmpeg` (static FFmpeg 7.0.2, GPLv3, with libx264, AAC, xfade, zoompan, gradients, libass) |
| ffprobe | not available → `vidforge` uses its own `ffmpeg -i` stderr parser (verified equivalent for duration/resolution/fps/codec/audio checks) |
| drawtext | **missing** in this build → all text overlays go through libass `subtitles` filter with generated `.ass` files (works, arguably better) |
| Fonts | DejaVu Sans (+ Noto CJK) present via fontconfig |
| Network | reachable (pypi.org HTTP 200) — used only for the one-time ffmpeg bootstrap |
| AI credentials | **none** in the environment (checked by name only; values never printed) |

## 2. What was implemented

A working, tested prototype (~2,300 lines, stdlib-only Python + FFmpeg):

- **Config layer** — typed validation of both project types with actionable
  error messages, duration bounds (reel 5–90 s, documentary 5–3600 s),
  auto-distributable scene durations, unknown-key warnings, strict mode.
- **Scene planner** — frame-exact quantization, half-beat grid snapping for
  reels (128 BPM demo: cuts moved 40–70 ms to land on beats), transition
  grouping (concat runs + xfade boundaries), final-timeline mapping.
- **Renderer** — per-scene cover-crop scaling for image/video/synthetic
  sources, Ken Burns zoom for images, loop-short-videos-with-warning, style
  presets (clean/vivid/muted/noir/retro), effects (shake, grain, mirror,
  beat-pulse), fade transitions, concat + xfade-chain assembly, ASS overlay
  burn (captions, title cards, labels, synthetic watermark), H.264/AAC MP4
  with faststart.
- **Audio** — pure-Python synthetic music bed/click/tone generation; BPM
  estimation by onset-envelope autocorrelation with octave disambiguation;
  full mix (music + per-scene narration files at timeline offsets, dB
  volumes, fades).
- **Subtitles** — SRT sidecars + burned captions; ASS override-tag injection
  from text is neutralized (tested).
- **Verification** — exists/size, probe (duration, resolution, fps, audio
  presence), full-decode check; true-negative tests prove it fails when
  expectations are wrong.
- **Reporting** — report.md / report.json / timeline.html per render, with
  mandatory honesty notes.
- **AI layer** — provider interface, null provider, OpenAI-compatible REST
  provider (bounded requests, env-var credentials, never auto-called),
  offline deterministic script drafter; `vidforge draft` works with zero
  network.
- **Automation** — one command end-to-end (`scripts/produce.sh` /
  `vidforge render`): read → validate → check assets → plan → render →
  assemble → burn → mix → mux → verify → report.

## 3. Required tests — results

| # | Requirement | Result | Evidence |
|---|---|---|---|
| 1 | 15 s synthetic vertical reel | **PASS** | `out/anime_reel_15s/neon_slash_reel.mp4` — 720x1280@30, final 14.60 s (one 0.4 s dissolve), 1,030 KiB, audio present, full decode clean, 8/8 verification checks PASS |
| 2 | 30 s synthetic landscape documentary | **PASS** | `out/documentary_30s/lighthouse_30s.mp4` — 1280x720@30, final 29.40 s, 1,526 KiB, 8/8 checks PASS; narration-missing warning correctly reported |
| 3 | Duration configurable, not hardcoded | **PASS** | 45 s documentary rendered: `out/documentary_45s/harbor_45s.mp4`, final 44.00 s (two 0.5 s blends), 8/8 checks PASS; plan-level tests also cover 15/30/90/180/240/900/1800/2700/3600 s |
| 4 | 15-min plan without 15-min render | **PASS** | `examples/documentary_15min_plan.json` → 13 scenes, 27,000 frames = exactly 900.00 s, final timeline 897.60 s, monotonic starts; **no render performed** (plan-only test). A 60-min draft plan (108,000 frames) also validates. |
| 5 | Missing assets / invalid configs | **PASS** | 14 tests: missing scene source (error lists scene id + every searched path), missing music file, unsupported extension, duration-sum mismatch, bad type, duplicate ids, unknown transitions, nonexistent config — all produce specific, actionable errors before any rendering |
| 6 | Sample audio combined with video | **PASS** | Two ways: (a) pipeline mixes a synthetic music WAV into Tests 1–3 outputs — audio stream verified present + decodable; (b) standalone test muxes a generated 2 s tone WAV with a rendered clip and passes `verify_output` |

Additional coverage: BPM estimator vs. click tracks at 96/128/160 BPM (all
within ±2.5), 120/90 BPM synthetic beds (within ±3 after the octave fix),
beat-grid alignment, real image source with Ken Burns zoom at correct output
resolution, real video source looped to fill a longer scene, ASS injection
safety, verifier true-negatives, AI provider behaviors, offline drafts
loadable as valid configs for every canonical documentary duration.

## 4. Failures during development (all fixed; none remain)

Honest list of what broke on the way to green:

1. Auto-distribution formula gave one scene the entire remaining budget (math bug) — fixed + unit-tested.
2. concat demuxer resolved relative paths against the list file — switched to absolute paths.
3. `shake` effect changed resolution and broke xfade size matching — now re-scales after jitter crop.
4. ASS style dict missed `SecondaryColour` (KeyError) — fixed.
5. Music files went through the image/video resolver and rejected `.wav` — added an audio-aware resolver.
6. Example 15-min config scene durations summed to 790 s, not 900 s — corrected.
7. BPM estimator reported 60 for the 120 BPM bed (true 2-beat periodicity) — added octave-candidate scoring (≥60 % of best score) with 120 BPM preference; documented as heuristic.
8. Several test expectations were themselves wrong (transition-in semantics, frame-quantized beat grid, 45 s final duration after two blends) — tests corrected against the (verified-correct) engine behaviour.

## 5. Actual size of the generated project

- Total: **4.8 MB, 84 files** (budget: ≤50 MB) — code 389 KB, tests 177 KB,
  examples 28 KB, rendered outputs + reports 4.2 MB.
- Outputs: 1,030 + 1,526 + 1,585 KiB MP4s, ~0.4 KB SRTs, small reports.
- The FFmpeg bootstrap binary (79.8 MB static) lives in Python site-packages,
  outside the project; it is **not** persisted in the workspace snapshot and
  must be re-provisioned in a fresh session (`pip install imageio-ffmpeg`
  or system ffmpeg).

## 6. Were the MP4 outputs verified?

**Yes.** Every exported MP4 passed all 8 machine checks: file exists and is
non-trivial; ffprobe-equivalent metadata (codec h264, exact resolution,
fps); duration within tolerance of the plan; audio stream present when
requested (AAC); aspect ratio; and a **full decode** (`ffmpeg -v error -i
file -f null -`) with zero errors. The verifier's failure modes were also
tested (wrong expectations ⇒ FAIL). Additionally, burned text overlays were
confirmed programmatically by extracting frames and measuring text-pixel
coverage in caption/title/watermark regions.

## 7. Features that require external APIs or additional assets

| Feature | Status | Needs |
|---|---|---|
| AI scriptwriting / scene descriptions | interface + provider implemented, **untested** (no credentials here) | `OPENAI_API_KEY` (or any OpenAI-compatible endpoint); opt-in via `draft --ai` |
| AI image generation | implemented, **untested** | same; image-capable endpoint |
| AI video generation | **not implemented** (raises by design) | provider-specific implementation |
| TTS narration audio | **not implemented** in bundled providers | a TTS provider or user-supplied `narration/<scene_id>.wav` files |
| Real footage/music | pipeline fully works with user files (tested with generated image/video/audio) | your own licensed media |
| Real beat-sync on actual music | estimator tested only on synthetic audio | your music files (or set `bpm` explicitly) |

## 8. Moving to a MacBook Air M1 (8 GB RAM)

- **FFmpeg:** `brew install ffmpeg` (includes libx264, AAC, libass,
  drawtext, ffprobe). `vidforge` auto-detects it on PATH — no code changes.
  Apple Silicon also unlocks `h264_videotoolbox`/`hevc_videotoolbox`
  hardware encoders (add to the encoder preference list in `env.py` for
  ~5–10× faster scene encodes).
- **Python:** any Homebrew/python.org 3.9+; no packages needed.
- **Fonts:** macOS ships Helvetica/Arial — either install DejaVu
  (`brew install font-dejavu`) or make the ASS font name configurable
  (one-line change in `subtitles.py`).
- **RAM:** 8 GB is ample — this sandbox rendered on 2 GB. Long-form renders
  are CPU-bound; the M1 will be several times faster than this 2-vCPU VM.
- **Storage:** project + outputs measured in MB; a 60-min 1080p render
  would still fit comfortably (roughly 300–800 MB at CRF 23).
- **Optional:** local LLMs (Ollama/LM Studio) expose OpenAI-compatible
  endpoints — point `OPENAI_BASE_URL` at them to test the AI layer without
  cloud spend.

## 9. Most important next step

**Wire real TTS narration into the documentary workflow** (implement
`generate_narration_audio` for one provider — e.g. OpenAI
`/audio/speech` or a local Piper install — writing
`narration/<scene_id>.wav` files the mixer already consumes). That single
addition turns the documentary pipeline from "synthetic placeholder" into
genuinely publishable output, because every other stage (script → scenes →
plan → render → subtitles → mix → verify) is already built and tested.
