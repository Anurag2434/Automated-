"""Report generation: report.md, report.json, and timeline.html.

The Markdown report always states exactly what was rendered (including the
synthetic/real status of every source and whether AI was used), so a reader
can never mistake a synthetic test render for real footage.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from .render import RenderResult, Renderer

from .assets import parse_synthetic


def _env_section(renderer: "Renderer") -> list:
    caps = renderer.caps.summary()
    return [
        f"- ffmpeg: `{caps['ffmpeg']}` ({caps['version']})",
        f"- probe tool: `{caps['ffprobe'] or 'ffmpeg-stderr fallback'}`",
        f"- H.264 encoder: `{caps['h264_encoder']}`, audio encoder: `{caps['aac_encoder']}`",
        f"- libass subtitles filter: {'yes' if caps['key_filters']['subtitles'] else 'NO'}",
        f"- fonts found: {caps['fonts_found']}",
    ]


def write_report_md(result: "RenderResult", renderer: "Renderer") -> Path:
    cfg = renderer.cfg
    plan = result.plan
    p = renderer.out_dir / "report.md"
    lines: list = []
    ap = lines.append
    ap(f"# Render report — {cfg.project.name}")
    ap("")
    ap(f"- Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    ap(f"- Config: `{result.config_path}`")
    ap(f"- Type: **{cfg.project.type}**, duration target "
       f"**{cfg.project.duration:g}s**, output "
       f"**{cfg.project.width}x{cfg.project.height} @ {cfg.project.fps} fps**")
    ap(f"- Output: `{result.output_path}`" if result.output_path else "- Output: (dry run)")
    if result.srt_path:
        ap(f"- Subtitles sidecar: `{result.srt_path}`")
    ap(f"- Result: **{'PASS' if result.ok else 'FAIL'}**")
    ap("")
    ap("## Environment")
    ap("")
    lines.extend(_env_section(renderer))
    ap("")
    ap("## Scene plan")
    ap("")
    if plan:
        ap("| # | id | start | dur (s) | source | transition | subtitle? |")
        ap("|---|----|-------|---------|--------|------------|-----------|")
        for s in plan.scenes:
            synth = parse_synthetic(s.source) is not None
            src = "SYNTHETIC" if synth else s.source
            ap(f"| {s.index + 1} | {s.id} | {s.final_start:.2f} | {s.duration:.2f} "
               f"| {src} | {s.transition_in} | {'yes' if (s.subtitle or s.narration) else '-'} |")
        ap("")
        if plan.bpm:
            ap(f"- Beat sync: {plan.bpm:g} BPM"
               + (f", grid {plan.beat_grid:.3f}s/beat" if plan.beat_grid else "")
               + f". Final timeline {plan.final_total:.2f}s "
                 f"(pre-transition {plan.total:.2f}s).")
        for note in plan.notes:
            ap(f"- note: {note}")
        ap("")
    ap("## Audio")
    ap("")
    ar = result.audio_report or {}
    ap(f"- Music: {ar.get('music') or 'none'}")
    ncl = ar.get("narration_clips") or []
    ap(f"- Narration clips used: {len(ncl)}"
       + (f" ({', '.join(ncl)})" if ncl else ""))
    for w in ar.get("warnings") or []:
        ap(f"- warning: {w}")
    ap("")
    ap("## Output verification")
    ap("")
    if result.verify:
        ap("| check | result | detail |")
        ap("|-------|--------|--------|")
        for c in result.verify.checks:
            ap(f"| {c.name} | {'PASS' if c.ok else 'FAIL'} | {c.detail} |")
    else:
        ap("(no output to verify)")
    ap("")
    if result.warnings:
        ap("## Warnings")
        ap("")
        for w in result.warnings:
            ap(f"- {w}")
        ap("")
    if result.errors:
        ap("## Errors")
        ap("")
        for e in result.errors:
            ap(f"- {e}")
        ap("")
    ap("## Honesty notes")
    ap("")
    n_synth = sum(1 for s in plan.scenes if parse_synthetic(s.source) is not None) if plan else 0
    if plan and n_synth == len(plan.scenes):
        ap("- **All visuals in this render are SYNTHETIC TEST GRAPHICS** "
           "(generated gradients + text). No real footage was used or produced.")
    elif plan and n_synth:
        ap(f"- {n_synth}/{len(plan.scenes)} scenes use synthetic placeholder graphics.")
    if plan and not result.audio_report:
        ap("- No audio mix was requested/possible for this render.")
    ar_music = (result.audio_report or {}).get("music") or ""
    if "synthetic" in str(ar_music):
        ap("- The music bed is a **synthetic placeholder** (kick/hat/pad test tones), "
           "not licensed music.")
    if not (result.audio_report or {}).get("narration_clips"):
        ap("- No narration audio was mixed (no narration files and no TTS run).")
    ap("- No AI generation was used in this render "
       "(AI providers are optional and disabled by default).")
    ap("")
    ap(f"- Timings (s): {json.dumps(result.timings)}")
    ap(f"- Sizes: {json.dumps(result.sizes)}")
    p.write_text("\n".join(lines), encoding="utf-8")
    return p


def write_report_json(result: "RenderResult") -> Path:
    p = result.output_path.parent / "report.json" if result.output_path else None
    if p is None:
        p = Path("report.json")
    p.write_text(json.dumps(result.to_dict(), indent=2), encoding="utf-8")
    return p


PALETTE = ["#ff2d78", "#7a2dff", "#12e6c8", "#ffb020", "#4d9fff", "#ff7847"]


def write_timeline_html(result: "RenderResult", renderer: "Renderer") -> Path:
    """Self-contained HTML timeline (inline CSS only, no external assets)."""
    plan = result.plan
    p = renderer.out_dir / "timeline.html"
    if not plan:
        p.write_text("<html><body><h3>No plan (render failed before planning)</h3></body></html>",
                     encoding="utf-8")
        return p
    total = plan.final_total or 1.0
    rows = []
    for i, s in enumerate(plan.scenes):
        left = s.final_start / total * 100
        width = s.duration / total * 100
        color = PALETTE[i % len(PALETTE)]
        synth = parse_synthetic(s.source) is not None
        label = f"{s.id}{' (SYNTH)' if synth else ''} — {s.duration:.2f}s"
        rows.append(
            f'<div class="row"><div class="bar" style="margin-left:{left:.3f}%;'
            f'width:{width:.3f}%;background:{color}">{label}</div></div>'
        )
    beat_html = ""
    if plan.beat_grid:
        marks = []
        t = 0.0
        while t < total:
            pos = t / total * 100
            marks.append(f'<div class="beat" style="left:{pos:.3f}%"></div>')
            t += plan.beat_grid / 2
        beat_html = ('<div class="ruler">' + "".join(marks)
                     + f'<span class="lbl">beat grid: {plan.bpm:g} BPM '
                       f'(half-beat markers)</span></div>')
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{renderer.cfg.project.name} — timeline</title>
<style>
 body {{ font-family: -apple-system, 'Segoe UI', sans-serif; background:#14161c; color:#e8e8f0; margin:24px; }}
 h1 {{ font-size:20px; }} h2 {{ font-size:14px; color:#9aa0b4; font-weight:normal; }}
 .wrap {{ max-width:960px; }}
 .row {{ height:34px; margin:4px 0; position:relative; background:#1e2230; border-radius:6px; }}
 .bar {{ height:100%; border-radius:6px; display:flex; align-items:center; padding:0 10px;
        font-size:12px; color:#101018; font-weight:600; white-space:nowrap; overflow:hidden; }}
 .ruler {{ position:relative; height:22px; margin-top:10px; border-top:1px solid #333a4d; }}
 .beat {{ position:absolute; top:0; width:1px; height:10px; background:#5a637f; }}
 .lbl {{ position:absolute; top:12px; left:4px; font-size:11px; color:#8b93a8; }}
 .meta {{ font-size:12px; color:#9aa0b4; margin-top:18px; }}
</style></head><body><div class="wrap">
<h1>{renderer.cfg.project.name} — scene timeline (final)</h1>
<h2>{renderer.cfg.project.type} · {plan.final_total:.2f}s ·
{plan.width}x{plan.height} @ {plan.fps}fps</h2>
{''.join(rows)}
{beat_html}
<div class="meta">Synthetic scenes are marked (SYNTH). Bars are positioned on the
final (post-transition) timeline.</div>
</div></body></html>"""
    p.write_text(html, encoding="utf-8")
    return p


def write_reports(result: "RenderResult", renderer: "Renderer") -> Path:
    write_report_json(result)
    write_timeline_html(result, renderer)
    return write_report_md(result, renderer)
