"""Environment layer: locate FFmpeg, detect capabilities, probe media files.

This module has no third-party dependencies. It discovers an FFmpeg binary via
(in order of precedence):

1. The ``VIDFORGE_FFMPEG`` environment variable.
2. ``ffmpeg`` on PATH.
3. ``<project root>/bin/ffmpeg`` (drop a static build here to make the
   project self-contained).
4. The ``imageio-ffmpeg`` Python package, if installed (used to bootstrap
   this sandbox; not a hard dependency).

FFprobe is optional: when absent, :func:`probe_media` falls back to parsing
``ffmpeg -i`` stderr, which is sufficient for duration / resolution / codec /
audio-presence checks.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import List, Optional

_PROJECT_ROOT = Path(__file__).resolve().parent.parent


class ToolError(RuntimeError):
    """Raised when a required external tool is missing or fails."""


# ---------------------------------------------------------------------------
# Binary discovery
# ---------------------------------------------------------------------------

def find_ffmpeg() -> str:
    """Return a path to an ffmpeg binary, or raise ToolError."""
    candidates: List[str] = []
    env_val = os.environ.get("VIDFORGE_FFMPEG")
    if env_val:
        candidates.append(env_val)
    which = shutil.which("ffmpeg")
    if which:
        candidates.append(which)
    candidates.append(str(_PROJECT_ROOT / "bin" / "ffmpeg"))
    try:  # optional bootstrap: imageio-ffmpeg wheel ships a static build
        import imageio_ffmpeg  # type: ignore

        candidates.append(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception:
        pass
    for cand in candidates:
        if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
            return cand
    raise ToolError(
        "No usable ffmpeg binary found. Tried: "
        + ", ".join(candidates or ["(none)"])
        + ". Install ffmpeg (apt/brew), set VIDFORGE_FFMPEG, drop a static "
        "build into ./bin/ffmpeg, or `pip install imageio-ffmpeg`."
    )


def find_ffprobe(ffmpeg: str) -> Optional[str]:
    """Return a path to ffprobe next to ffmpeg or on PATH, else None."""
    which = shutil.which("ffprobe")
    if which:
        return which
    sibling = Path(ffmpeg).with_name("ffprobe")
    if sibling.is_file() and os.access(sibling, os.X_OK):
        return str(sibling)
    return None


def _run(cmd: List[str], timeout: int = 120) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd, capture_output=True, text=True, timeout=timeout, check=False
    )


# ---------------------------------------------------------------------------
# Capability detection (cached per process)
# ---------------------------------------------------------------------------

@dataclass
class Caps:
    """Snapshot of what the local FFmpeg build can do."""

    ffmpeg: str
    ffprobe: Optional[str]
    version: str
    filters: set = field(default_factory=set)
    encoders: set = field(default_factory=set)
    h264_encoder: str = "libx264"
    aac_encoder: str = "aac"
    amix_normalize: bool = False
    fonts: List[str] = field(default_factory=list)

    def has_filter(self, name: str) -> bool:
        return name in self.filters

    def summary(self) -> dict:
        return {
            "ffmpeg": self.ffmpeg,
            "ffprobe": self.ffprobe,
            "version": self.version.splitlines()[0] if self.version else "",
            "h264_encoder": self.h264_encoder,
            "aac_encoder": self.aac_encoder,
            "amix_normalize": self.amix_normalize,
            "key_filters": {
                f: self.has_filter(f)
                for f in (
                    "subtitles",
                    "xfade",
                    "zoompan",
                    "gradients",
                    "eq",
                    "noise",
                    "amix",
                    "adelay",
                    "afade",
                    "drawtext",
                )
            },
            "fonts_found": len(self.fonts),
        }


_FONT_DIRS = (
    "/usr/share/fonts",
    "/usr/local/share/fonts",
    str(Path.home() / ".fonts"),
    "/System/Library/Fonts",  # macOS
)
_FONT_NAMES = (
    "DejaVuSans-Bold.ttf",
    "DejaVuSans.ttf",
    "LiberationSans-Bold.ttf",
    "LiberationSans-Regular.ttf",
    "NotoSans-Bold.ttf",
    "Arial Bold.ttf",
    "Arial.ttf",
)


def _find_fonts() -> List[str]:
    found: List[str] = []
    for base in _FONT_DIRS:
        root = Path(base)
        if not root.is_dir():
            continue
        for name in _FONT_NAMES:
            try:
                hits = sorted(root.rglob(name))
            except OSError:
                continue
            for h in hits:
                found.append(str(h))
    # De-duplicate, keep order
    seen = set()
    out = []
    for f in found:
        if f not in seen:
            seen.add(f)
            out.append(f)
    return out


@lru_cache(maxsize=1)
def get_caps() -> Caps:
    """Detect FFmpeg capabilities once per process."""
    ffmpeg = find_ffmpeg()
    proc = _run([ffmpeg, "-version"])
    if proc.returncode != 0:
        raise ToolError(f"ffmpeg -version failed: {proc.stderr[:300]}")
    version = proc.stdout.splitlines()[0] if proc.stdout else "unknown"

    filters: set = set()
    proc = _run([ffmpeg, "-hide_banner", "-filters"])
    for line in proc.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2 and re.fullmatch(r"[TSC.]+", parts[0]):
            filters.add(parts[1])

    encoders: set = set()
    proc = _run([ffmpeg, "-hide_banner", "-encoders"])
    for line in proc.stdout.splitlines():
        m = re.match(r"\s*[A-Z.]{6}\s+(\S+)", line)
        if m:
            encoders.add(m.group(1))

    proc = _run([ffmpeg, "-hide_banner", "-h", "filter=amix"])
    amix_normalize = "normalize" in (proc.stdout + proc.stderr)

    h264 = next((e for e in ("libx264", "libopenh264", "h264") if e in encoders), None)
    if h264 is None:
        h264 = "mpeg4" if "mpeg4" in encoders else ""
    aac = "aac" if "aac" in encoders else ("libmp3lame" if "libmp3lame" in encoders else "")

    return Caps(
        ffmpeg=ffmpeg,
        ffprobe=find_ffprobe(ffmpeg),
        version=version,
        filters=filters,
        encoders=encoders,
        h264_encoder=h264,
        aac_encoder=aac,
        amix_normalize=amix_normalize,
        fonts=_find_fonts(),
    )


# ---------------------------------------------------------------------------
# Media probing (ffprobe when available, else ffmpeg stderr parser)
# ---------------------------------------------------------------------------

_DUR_RE = re.compile(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)")
_VID_RE = re.compile(r"Stream #\d+:\d+.*?:\s*Video:\s*(\S+)")
_RES_RE = re.compile(r"Stream #\d+:\d+.*?:\s*Video:.*?,\s*(\d{2,5})x(\d{2,5})")
_FPS_RE = re.compile(r"(\d+(?:\.\d+)?)\s*fps")
_TBR_RE = re.compile(r"(\d+(?:\.\d+)?)\s*tbr")
_AUD_RE = re.compile(r"Stream #\d+:\d+.*?:\s*Audio:\s*(\S+)")


def probe_media(path: str | Path, caps: Optional[Caps] = None) -> Optional[dict]:
    """Inspect a media file.

    Returns a dict with keys: duration, width, height, fps, video_codec,
    audio_codec, has_audio, probe_tool. Returns None if the file cannot be
    opened (missing, unreadable, or not media).
    """
    path = str(path)
    if not os.path.isfile(path):
        return None
    caps = caps or get_caps()
    if caps.ffprobe:
        proc = _run(
            [
                caps.ffprobe,
                "-v", "error",
                "-show_entries",
                "format=duration:stream=codec_type,codec_name,width,height,avg_frame_rate",
                "-of", "json",
                path,
            ]
        )
        if proc.returncode == 0 and proc.stdout.strip():
            try:
                data = json.loads(proc.stdout)
            except json.JSONDecodeError:
                data = None
            if data:
                out = {
                    "duration": None,
                    "width": None,
                    "height": None,
                    "fps": None,
                    "video_codec": None,
                    "audio_codec": None,
                    "has_audio": False,
                    "probe_tool": "ffprobe",
                }
                try:
                    dur = data.get("format", {}).get("duration")
                    if dur is not None:
                        out["duration"] = float(dur)
                except (TypeError, ValueError):
                    pass
                for st in data.get("streams", []):
                    ctype = st.get("codec_type")
                    if ctype == "video" and out["video_codec"] is None:
                        out["video_codec"] = st.get("codec_name")
                        out["width"] = st.get("width")
                        out["height"] = st.get("height")
                        rate = st.get("avg_frame_rate") or "0/0"
                        try:
                            num, den = rate.split("/")
                            if int(den):
                                out["fps"] = round(int(num) / int(den), 3) or None
                        except (ValueError, ZeroDivisionError):
                            pass
                    elif ctype == "audio" and not out["has_audio"]:
                        out["has_audio"] = True
                        out["audio_codec"] = st.get("codec_name")
                return out

    # Fallback: parse `ffmpeg -i <file>` stderr.
    proc = _run([caps.ffmpeg, "-hide_banner", "-i", path], timeout=60)
    blob = proc.stderr or ""
    if "No such file" in blob or proc.returncode not in (0, 1):
        return None
    info = {
        "duration": None,
        "width": None,
        "height": None,
        "fps": None,
        "video_codec": None,
        "audio_codec": None,
        "has_audio": bool(_AUD_RE.search(blob)),
        "probe_tool": "ffmpeg-stderr",
    }
    m = _DUR_RE.search(blob)
    if m:
        h, mi, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
        d = h * 3600 + mi * 60 + s
        if d > 0:  # images/streams report N/A or 0
            info["duration"] = d
    m = _VID_RE.search(blob)
    if m:
        info["video_codec"] = m.group(1)
    m = _RES_RE.search(blob)
    if m:
        info["width"], info["height"] = int(m.group(1)), int(m.group(2))
    m = _FPS_RE.search(blob)
    if m:
        info["fps"] = float(m.group(1))
    else:
        m = _TBR_RE.search(blob)
        if m:
            info["fps"] = float(m.group(1))
    m = _AUD_RE.search(blob)
    if m:
        info["audio_codec"] = m.group(1)
    if info["video_codec"] is None and info["audio_codec"] is None:
        return None
    return info


def decode_check(path: str | Path, caps: Optional[Caps] = None) -> tuple:
    """Fully decode a file to null sink. Returns (ok, error_text)."""
    caps = caps or get_caps()
    proc = _run([caps.ffmpeg, "-v", "error", "-i", str(path), "-f", "null", "-"], timeout=600)
    err = (proc.stderr or "").strip()
    return proc.returncode == 0 and not err, err[:500]
