"""Scene planning: durations, frame quantization, beat alignment, transitions.

The plan is the single source of truth shared by rendering, audio and
subtitles. All durations are quantized to whole frames so concat/xfade math is
exact, and (for anime_reel projects with a known BPM) scene cuts are snapped
to the beat grid.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from .config import ProjectConfig, XFADE_TRANSITIONS

MIN_SCENE_FRAMES = 3


@dataclass
class PlannedScene:
    index: int
    id: str
    title: str
    frames: int                 # duration in frames (exact)
    duration: float             # seconds (frames / fps)
    start: float                # seconds, pre-transition timeline
    source: str
    visual: str
    subtitle: str
    narration: str
    transition_in: str          # config name (cut/fade/.../dissolve/...)
    effect: Optional[str] = None
    final_start: float = 0.0    # seconds, final timeline (after xfade overlaps)

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "id": self.id,
            "title": self.title,
            "start": round(self.start, 3),
            "final_start": round(self.final_start, 3),
            "duration": round(self.duration, 3),
            "frames": self.frames,
            "source": self.source,
            "subtitle": self.subtitle,
            "narration": self.narration,
            "transition_in": self.transition_in,
            "effect": self.effect,
        }


@dataclass
class Segment:
    """A run of scenes joined by cuts; segments are joined by xfade blends."""

    start_index: int
    end_index: int              # inclusive
    frames: int

    @property
    def duration(self) -> float:
        return self.frames / Segment.fps

    fps: float = 30.0  # class attribute, set by build_plan


@dataclass
class ScenePlan:
    scenes: List[PlannedScene]
    fps: int
    width: int
    height: int
    total_frames: int
    final_total_frames: int
    bpm: Optional[float] = None
    beat_grid: Optional[float] = None     # seconds per beat, if aligned
    notes: List[str] = field(default_factory=list)
    segments: List[Segment] = field(default_factory=list)
    xfade_boundaries: List[dict] = field(default_factory=list)

    @property
    def total(self) -> float:
        return self.total_frames / self.fps

    @property
    def final_total(self) -> float:
        return self.final_total_frames / self.fps

    def scene_by_id(self, sid: str) -> Optional[PlannedScene]:
        for s in self.scenes:
            if s.id == sid:
                return s
        return None

    def to_dict(self) -> dict:
        return {
            "fps": self.fps,
            "resolution": [self.width, self.height],
            "total_seconds": round(self.total, 3),
            "final_total_seconds": round(self.final_total, 3),
            "total_frames": self.total_frames,
            "bpm": self.bpm,
            "beat_grid": round(self.beat_grid, 4) if self.beat_grid else None,
            "notes": self.notes,
            "scenes": [s.to_dict() for s in self.scenes],
        }


def is_xfade(transition: str) -> bool:
    return transition in XFADE_TRANSITIONS


# ---------------------------------------------------------------------------
# Plan construction
# ---------------------------------------------------------------------------

def build_plan(cfg: ProjectConfig, bpm: Optional[float] = None) -> ScenePlan:
    """Turn a validated config into an executable, frame-exact scene plan."""
    fps = cfg.project.fps
    Segment.fps = float(fps)
    total_frames = round(cfg.project.duration * fps)
    notes: List[str] = []

    # 1. Resolve scene durations (auto-distribute nulls), quantize to frames.
    scenes = list(cfg.scenes)
    fixed_frames: List[Optional[int]] = [
        round(s.duration * fps) if s.duration is not None else None for s in scenes
    ]
    auto_idx = [i for i, f in enumerate(fixed_frames) if f is None]
    remaining = total_frames - sum(f for f in fixed_frames if f is not None)
    if auto_idx:
        n_auto = len(auto_idx)
        base = remaining // n_auto
        extra = remaining - base * n_auto
        for j, i in enumerate(auto_idx):
            fixed_frames[i] = base + (1 if j < extra else 0)
        notes.append(
            f"Auto-distributed {remaining / fps:.2f}s across {n_auto} "
            "scene(s) without explicit duration."
        )

    # 2. Beat alignment (anime_reel only, when a BPM is known).
    beat_grid = None
    if cfg.project.is_reel and cfg.beat_sync and bpm:
        beat_grid = 60.0 / bpm
        half = beat_grid / 2.0
        fixed_frames, beat_notes = _snap_cuts_to_grid(
            [f if f is not None else 0 for f in fixed_frames],
            total_frames, half, fps,
        )
        notes.extend(beat_notes)
        notes.append(f"Beat sync: {bpm:g} BPM, grid {half:.3f}s (half-beats).")

    # 3. Enforce exact total (absorb rounding drift in the last scene).
    frames: List[int] = [f if f is not None else 0 for f in fixed_frames]
    drift = total_frames - sum(frames)
    if drift:
        frames[-1] += drift
    too_short = [scenes[i].id for i, f in enumerate(frames) if f < MIN_SCENE_FRAMES]
    if too_short:
        raise ValueError(
            f"Scene(s) {too_short} would be shorter than {MIN_SCENE_FRAMES} frames "
            "after planning; use fewer scenes or a longer duration."
        )

    # 4. Materialize the plan with pre-transition starts.
    planned: List[PlannedScene] = []
    acc = 0
    for i, sc in enumerate(scenes):
        planned.append(PlannedScene(
            index=i,
            id=sc.id,
            title=sc.title,
            frames=frames[i],
            duration=frames[i] / fps,
            start=acc / fps,
            source=sc.source,
            visual=sc.visual,
            subtitle=sc.subtitle,
            narration=sc.narration,
            transition_in="cut" if i == 0 else sc.transition_in,
            effect=sc.effect,
        ))
        acc += frames[i]

    plan = ScenePlan(
        scenes=planned,
        fps=fps,
        width=cfg.project.width,
        height=cfg.project.height,
        total_frames=total_frames,
        final_total_frames=total_frames,
        bpm=bpm,
        beat_grid=beat_grid,
        notes=notes,
    )

    # 5. Transition grouping + final timeline (xfade overlaps shorten it).
    plan.segments, plan.xfade_boundaries, plan.final_total_frames = (
        _group_segments(plan, cfg)
    )
    _assign_final_starts(plan)
    return plan


def _snap_cuts_to_grid(frames: List[int], total_frames: int,
                       grid_seconds: float, fps: int) -> Tuple[List[int], List[str]]:
    """Snap interior cut points to the nearest multiple of grid_seconds."""
    notes: List[str] = []
    grid_frames = max(1, round(grid_seconds * fps))
    cuts = []
    acc = 0
    for f in frames[:-1]:
        acc += f
        cuts.append(acc)
    snapped: List[int] = []
    for c in cuts:
        s = max(
            (snapped[-1] if snapped else 0) + MIN_SCENE_FRAMES,
            round(c / grid_frames) * grid_frames,
        )
        if s != c:
            notes.append(
                f"Beat snap: cut at {c / fps:.2f}s -> {s / fps:.2f}s "
                f"(grid {grid_frames / fps:.3f}s)."
            )
        snapped.append(s)
    snapped.append(total_frames)
    out: List[int] = []
    prev = 0
    for s in snapped:
        out.append(max(MIN_SCENE_FRAMES, s - prev))
        prev += out[-1]
    out[-1] += total_frames - sum(out)   # keep exact total
    return out, notes


def _group_segments(plan: ScenePlan, cfg: ProjectConfig
                    ) -> Tuple[List[Segment], List[dict], int]:
    """Group scenes into concat-runs separated by xfade blends.

    Returns (segments, boundaries, final_total_frames). Each boundary dict:
    {"after_index": i, "name": xfade-name, "frames": overlap-frames}.
    """
    scenes = plan.scenes
    fps = plan.fps
    td_frames = max(1, round(cfg.render.transition_duration * fps))

    boundaries: List[dict] = []
    segments: List[Segment] = []
    seg_start = 0

    def close_segment(end_index: int) -> None:
        segments.append(Segment(
            start_index=seg_start,
            end_index=end_index,
            frames=sum(s.frames for s in scenes[seg_start:end_index + 1]),
        ))

    for i in range(1, len(scenes)):
        if is_xfade(scenes[i].transition_in):
            f = min(
                td_frames,
                max(1, int(scenes[i - 1].frames * 0.4)),
                max(1, int(scenes[i].frames * 0.4)),
            )
            boundaries.append({
                "after_index": i - 1,
                "name": XFADE_TRANSITIONS[scenes[i].transition_in],
                "frames": f,
                "config_name": scenes[i].transition_in,
            })
            close_segment(i - 1)
            seg_start = i
    close_segment(len(scenes) - 1)

    final_total = plan.total_frames - sum(b["frames"] for b in boundaries)
    return segments, boundaries, final_total


def _assign_final_starts(plan: ScenePlan) -> None:
    """Compute each scene's start in the final (post-xfade) timeline."""
    scenes = plan.scenes
    fps = plan.fps
    boundary_by_after = {b["after_index"]: b for b in plan.xfade_boundaries}
    pre_seg_start = 0.0      # pre-transition timeline position of current segment
    overlap_cum = 0.0        # seconds of overlap accumulated so far
    for seg in plan.segments:
        b = boundary_by_after.get(seg.start_index - 1)
        if b:
            overlap_cum += b["frames"] / fps
        pos = pre_seg_start
        for s in scenes[seg.start_index:seg.end_index + 1]:
            s.final_start = pos - overlap_cum
            pos += s.duration
        pre_seg_start = pos
