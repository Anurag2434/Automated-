"""The renderer: turns a ProjectConfig + ScenePlan into an MP4.

Pipeline (all steps logged and reported):

  1. load + validate config
  2. resolve/check source assets (fail with a list of ALL problems)
  3. build the scene plan (frame-exact, optionally beat-aligned)
  4. render each scene (cover-crop, style preset, effect, fades)
  5. assemble: concat for cut boundaries, xfade chain for blends
  6. burn text overlays via a generated .ass file (libass)
  7. build the audio mix (music + narration files, fades, dB volumes)
  8. mux video + audio -> H.264/AAC MP4 with faststart
  9. verify with probe + full decode, then write reports

Scenes whose source is "synthetic" render generated gradients, and every
synthetic scene carries a burned "SYNTHETIC TEST FOOTAGE" watermark.
"""

from __future__ import annotations

import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from . import audio as audio_mod
from . import env, subtitles as sub_mod, validation
from .assets import AssetError, check_assets, resolve_source
from .config import ConfigError, ProjectConfig, load_config
from .scenes import ScenePlan, build_plan
from .report import write_reports

SYNTHETIC_WATERMARK = "SYNTHETIC TEST FOOTAGE"

STYLE_CHAINS = {
    "clean": [],
    "vivid": ["eq=contrast=1.08:saturation=1.45", "vignette=PI/5"],
    "muted": ["eq=saturation=0.92:contrast=1.03"],
    "noir": ["hue=s=0", "eq=contrast=1.18:gamma=0.96"],
    "retro": ["noise=alls=6:allf=t+u", "eq=saturation=1.25:contrast=1.05"],
}


class RenderError(RuntimeError):
    """Raised when rendering cannot proceed or ffmpeg fails."""


@dataclass
class RenderResult:
    ok: bool
    config_path: Path
    output_path: Optional[Path] = None
    srt_path: Optional[Path] = None
    report_path: Optional[Path] = None
    plan: Optional[ScenePlan] = None
    assets_report: Optional[dict] = None
    audio_report: Optional[dict] = None
    verify: Optional[validation.VerifyResult] = None
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    timings: dict = field(default_factory=dict)
    sizes: dict = field(default_factory=dict)
    dry_run: bool = False

    def to_dict(self) -> dict:
        return {
            "ok": self.ok,
            "config": str(self.config_path),
            "output": str(self.output_path) if self.output_path else None,
            "subtitles": str(self.srt_path) if self.srt_path else None,
            "verify": self.verify.to_dict() if self.verify else None,
            "warnings": self.warnings,
            "errors": self.errors,
            "timings": self.timings,
            "sizes": self.sizes,
            "dry_run": self.dry_run,
            "plan": self.plan.to_dict() if self.plan else None,
        }


def _slug(name: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("_")
    return s or "project"


def _run_ffmpeg(cmd: List[str], what: str, timeout: int = 1200) -> None:
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    if proc.returncode != 0:
        tail = (proc.stderr or "").strip().splitlines()[-6:]
        raise RenderError(f"{what} failed:\n  " + "\n  ".join(tail))


def _esc_filter_path(p: str) -> str:
    """Escape a path for use inside a filtergraph argument."""
    return p.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")


class Renderer:
    def __init__(self, cfg: ProjectConfig, out_dir: Optional[Path] = None,
                 keep_temp: bool = False, quiet: bool = False):
        self.cfg = cfg
        self.caps = env.get_caps()
        if not self.caps.h264_encoder:
            raise RenderError(
                "This ffmpeg build has no H.264 encoder (looked for libx264/"
                "libopenh264/h264/mpeg4). Use a full ffmpeg build."
            )
        self.keep_temp = keep_temp or cfg.render.keep_temp
        self.quiet = quiet
        cfg_dir = cfg.path.resolve().parent
        default_out = cfg_dir / "out" / _slug(cfg.project.name)
        self.out_dir = Path(out_dir) if out_dir else default_out
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.work = self.out_dir / "_work"
        if self.work.exists():
            shutil.rmtree(self.work)
        self.work.mkdir(parents=True)
        self.warnings: List[str] = list(cfg.warnings)
        self.t0 = time.time()
        self.timings: dict = {}
        self.plan: Optional[ScenePlan] = None
        self.audio_report: Optional[dict] = None

    def log(self, msg: str) -> None:
        if not self.quiet:
            print(msg, flush=True)

    # ------------------------------------------------------------------
    # scene rendering
    # ------------------------------------------------------------------
    def _synthetic_source(self, index: int) -> str:
        palette = self.cfg.style.palette or ("#ff2d78", "#7a2dff")
        c0 = palette[index % len(palette)].lstrip("#")
        c1 = palette[(index + 1) % len(palette)].lstrip("#")
        use_gradient = self.caps.has_filter("gradients")
        if use_gradient:
            return (f"gradients=s={self.plan.width}x{self.plan.height}"
                    f":r={self.plan.fps}:c0=0x{c0}:c1=0x{c1}:speed=0.02")
        return f"color=c=0x{c0}:s={self.plan.width}x{self.plan.height}:r={self.plan.fps}"

    def _fade_filters(self, scene_index: int) -> List[str]:
        sc = self.plan.scenes[scene_index]
        fps = self.plan.fps
        out: List[str] = []
        td = min(self.cfg.render.transition_duration, sc.duration * 0.4)
        if scene_index > 0 and sc.transition_in == "fade" and td > 0:
            out.append(f"fade=t=in:st=0:d={td:.3f}")
        if scene_index > 0 and sc.transition_in == "fadewhite" and td > 0:
            out.append(f"fade=t=in:st=0:d={td:.3f}:color=white")
        if scene_index == len(self.plan.scenes) - 1 and self.cfg.render.fade_out > 0:
            fo = min(self.cfg.render.fade_out, sc.duration * 0.5)
            out.append(f"fade=t=out:st={sc.duration - fo:.3f}:d={fo:.3f}")
        return out

    def _effect_filters(self, scene_index: int) -> List[str]:
        sc = self.plan.scenes[scene_index]
        if not sc.effect:
            return []
        W, H = self.plan.width, self.plan.height
        if sc.effect == "grain":
            return ["noise=alls=10:allf=t"]
        if sc.effect == "mirror":
            return ["hflip"]
        if sc.effect == "shake":
            m = 10
            return [f"crop={W - 2 * m}:{H - 2 * m}:"
                    f"x='{m}+{m}*sin(t*13)':y='{m}+{m}*cos(t*17)',"
                    f"scale={W}:{H}"]
        if sc.effect == "beat_pulse":
            if not self.plan.bpm:
                self.warnings.append(
                    f"Scene '{sc.id}': beat_pulse needs a BPM; effect skipped."
                )
                return []
            bps = self.plan.bpm / 60.0
            return [f"eq=brightness='0.06*max(0,sin(2*PI*{bps:.4f}*t))':saturation=1.12"]
        if sc.effect == "zoom":
            # handled for images at input-build time; warn for other kinds
            spec = resolve_source(sc.source, self.cfg)
            if spec.kind != "image":
                self.warnings.append(
                    f"Scene '{sc.id}': effect 'zoom' only applies to image sources; ignored."
                )
            return []
        return []

    def render_scene(self, scene_index: int) -> Path:
        plan = self.plan
        sc = plan.scenes[scene_index]
        spec = resolve_source(sc.source, self.cfg)
        W, H, F = plan.width, plan.height, plan.fps
        N = sc.frames
        d = N / F
        out_path = self.work / f"scene_{scene_index:03d}.mp4"
        cmd = [self.caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-nostdin"]

        vf: List[str] = []
        cover = (f"scale={W}:{H}:force_original_aspect_ratio=increase,"
                 f"crop={W}:{H}")

        if spec.kind == "synthetic":
            cmd += ["-f", "lavfi", "-t", f"{d + 1.0:.3f}", "-i", self._synthetic_source(scene_index)]
            vf.append(f"trim=duration={d:.3f},setpts=PTS-STARTPTS")
            vf.append(cover)  # no-op at exact size, kept for uniformity
        elif spec.kind == "image":
            if sc.effect == "zoom":
                big_w, big_h = W * 2, H * 2
                zoom = (f"zoompan=z='min(1+0.12*on/{N},1.18)':"
                        f"x='(iw-iw/zoom)/2':y='(ih-ih/zoom)/2':"
                        f"d={N}:s={W}x{H}:fps={F}")
                cmd += ["-i", str(spec.path)]
                vf.append(f"scale={big_w}:{big_h}:force_original_aspect_ratio=increase")
                vf.append(f"crop={big_w}:{big_h}")
                vf.append(zoom)
            else:
                cmd += ["-loop", "1", "-t", f"{d + 1.0:.3f}", "-i", str(spec.path)]
                vf.append(f"trim=duration={d:.3f},setpts=PTS-STARTPTS")
                vf.append(cover)
        else:  # video
            info = env.probe_media(str(spec.path), self.caps)
            adur = (info or {}).get("duration") or 0.0
            if adur + 0.05 < d:
                cmd += ["-stream_loop", "-1"]
                self.warnings.append(
                    f"Scene '{sc.id}': source video is {adur:.2f}s; looping it to "
                    f"cover {d:.2f}s."
                )
            cmd += ["-i", str(spec.path)]
            vf.append(f"trim=duration={d:.3f},setpts=PTS-STARTPTS")
            vf.append(cover)

        vf.append(f"fps={F},setsar=1,format=yuv420p")
        vf += STYLE_CHAINS.get(self.cfg.style.preset, [])
        vf += self._effect_filters(scene_index)
        vf += self._fade_filters(scene_index)

        cmd += [
            "-vf", ",".join(vf),
            "-frames:v", str(N),
            "-r", str(F),
            "-c:v", self.caps.h264_encoder, "-preset", self.cfg.render.preset,
            "-crf", str(self.cfg.render.crf),
            "-pix_fmt", "yuv420p",
            str(out_path),
        ]
        self.log(f"    scene {sc.id} [{spec.kind}] {d:.2f}s ...")
        _run_ffmpeg(cmd, f"scene '{sc.id}' render")
        return out_path

    # ------------------------------------------------------------------
    # assembly
    # ------------------------------------------------------------------
    def _concat(self, paths: List[Path], out_path: Path) -> None:
        lst = self.work / "concat.txt"
        lst.write_text(
            "".join(f"file '{Path(p).resolve()}'\n" for p in paths),
            encoding="utf-8",
        )
        cmd = [self.caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
               "-nostdin", "-f", "concat", "-safe", "0", "-i", str(lst),
               "-c", "copy", str(out_path)]
        _run_ffmpeg(cmd, "concat")

    def assemble(self, scene_files: List[Path]) -> Path:
        plan = self.plan
        boundaries = plan.xfade_boundaries
        if not boundaries:
            out = self.work / "assembled.mp4"
            self._concat(scene_files, out)
            return out

        if not self.caps.has_filter("xfade"):
            raise RenderError(
                "This ffmpeg build lacks the xfade filter; use 'cut'/'fade' "
                "transitions or a full ffmpeg build."
            )
        # 1) concat each cut-run into a segment
        seg_files: List[Path] = []
        for si, seg in enumerate(plan.segments):
            seg_path = self.work / f"seg_{si:02d}.mp4"
            self._concat(scene_files[seg.start_index:seg.end_index + 1], seg_path)
            seg_files.append(seg_path)
        # 2) xfade chain across segments
        fps = plan.fps
        parts: List[str] = []
        prev = "[0:v]"
        cur_len = plan.segments[0].frames
        for k, b in enumerate(boundaries, start=1):
            td = b["frames"] / fps
            offset = (cur_len - b["frames"]) / fps
            label = f"[x{k}]" if k < len(boundaries) else "[xv]"
            parts.append(
                f"{prev}[{k}:v]xfade=transition={b['name']}:"
                f"duration={td:.6f}:offset={offset:.6f}{label}"
            )
            cur_len = cur_len + plan.segments[k].frames - b["frames"]
            prev = label
        parts.append("[xv]format=yuv420p[vout]")
        out = self.work / "assembled.mp4"
        cmd = [self.caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error", "-nostdin"]
        for f in seg_files:
            cmd += ["-i", str(f)]
        cmd += [
            "-filter_complex", ";".join(parts),
            "-map", "[vout]", "-r", str(fps),
            "-c:v", self.caps.h264_encoder, "-preset", self.cfg.render.preset,
            "-crf", str(self.cfg.render.crf), "-pix_fmt", "yuv420p",
            str(out),
        ]
        _run_ffmpeg(cmd, "xfade assembly")
        return out

    # ------------------------------------------------------------------
    # overlays + audio + mux
    # ------------------------------------------------------------------
    def burn_overlays(self, assembled: Path) -> Path:
        events = sub_mod.build_overlay_events(self.plan, self.cfg)
        if not events or not self.caps.has_filter("subtitles"):
            if events and not self.caps.has_filter("subtitles"):
                self.warnings.append(
                    "ffmpeg lacks the 'subtitles' (libass) filter: text overlays "
                    "skipped; .srt sidecar still written."
                )
            return assembled
        ass_path = sub_mod.write_ass(
            events, self.work / "overlays.ass",
            self.plan.width, self.plan.height, self.cfg,
        )
        out = self.work / "with_overlays.mp4"
        cmd = [self.caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
               "-nostdin", "-i", str(assembled),
               "-vf", f"subtitles={_esc_filter_path(str(ass_path))}",
               "-c:v", self.caps.h264_encoder, "-preset", self.cfg.render.preset,
               "-crf", str(self.cfg.render.crf), "-pix_fmt", "yuv420p",
               str(out)]
        _run_ffmpeg(cmd, "overlay burn")
        return out

    def mux(self, video: Path, audio: Optional[Path], out_path: Path) -> None:
        cmd = [self.caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
               "-nostdin", "-i", str(video)]
        if audio is not None:
            if not self.caps.aac_encoder:
                raise RenderError(
                    "No AAC/MP3 encoder in this ffmpeg build; cannot mux audio."
                )
            cmd += ["-i", str(audio), "-map", "0:v:0", "-map", "1:a:0",
                    "-c:v", "copy", "-c:a", self.caps.aac_encoder,
                    "-b:a", "160k", "-shortest"]
        else:
            cmd += ["-c", "copy"]
        cmd += ["-movflags", "+faststart", str(out_path)]
        _run_ffmpeg(cmd, "final mux")

    # ------------------------------------------------------------------
    # orchestration
    # ------------------------------------------------------------------
    def render(self) -> RenderResult:
        cfg = self.cfg
        result = RenderResult(ok=False, config_path=cfg.path)

        # 2. BPM (explicit, or estimated from a real music file)
        bpm = cfg.music.bpm
        if bpm is None and cfg.music.source not in ("synthetic", "none", "") \
                and cfg.audio_enabled:
            from .assets import resolve_audio_source
            music_file = resolve_audio_source(cfg.music.source, cfg)
            self.log(f"  estimating BPM from {music_file} ...")
            bpm = audio_mod.estimate_bpm(str(music_file), self.caps)
            self.log(f"  estimated {bpm} BPM")

        # 3. plan
        self.plan = build_plan(cfg, bpm)
        result.plan = self.plan
        self.warnings.extend(self.plan.notes)

        # 4. assets
        assets_report = check_assets(cfg, self.plan)
        result.assets_report = assets_report

        # 5. scenes
        self.log(f"  rendering {len(self.plan.scenes)} scene(s) ...")
        t = time.time()
        scene_files = [self.render_scene(i) for i in range(len(self.plan.scenes))]
        self.timings["scenes"] = round(time.time() - t, 1)

        # 6. assembly
        t = time.time()
        assembled = self.assemble(scene_files)
        self.timings["assembly"] = round(time.time() - t, 1)

        # 7. overlays
        t = time.time()
        final_video = self.burn_overlays(assembled)
        self.timings["overlays"] = round(time.time() - t, 1)

        # 8. audio
        t = time.time()
        audio_result = audio_mod.build_audio_track(cfg, self.plan, self.work, self.caps)
        self.audio_report = {
            "music": audio_result.music_source if audio_result.used_music else None,
            "narration_clips": audio_result.narration_clips,
            "warnings": audio_result.warnings,
        }
        result.audio_report = self.audio_report
        self.warnings.extend(audio_result.warnings)
        self.timings["audio"] = round(time.time() - t, 1)

        # 9. mux + sidecar files
        out_name = _slug(cfg.project.name)
        out_path = self.out_dir / f"{out_name}.mp4"
        t = time.time()
        self.mux(final_video, audio_result.path, out_path)
        self.timings["mux"] = round(time.time() - t, 1)
        result.output_path = out_path

        srt_path: Optional[Path] = None
        if cfg.subtitles.enabled:
            cues = sub_mod.build_caption_cues(self.plan, cfg)
            if cues:
                srt_path = sub_mod.write_srt(cues, self.out_dir / f"{out_name}.srt")
                result.srt_path = srt_path

        # 10. verify
        verify = validation.verify_output(
            out_path,
            expected_duration=self.plan.final_total,
            width=cfg.project.width, height=cfg.project.height,
            fps=cfg.project.fps,
            expect_audio=audio_result.path is not None,
            duration_tolerance=max(0.4, 2.5 / cfg.project.fps),
            caps=self.caps,
        )
        result.verify = verify
        result.warnings = self.warnings

        # 11. sizes
        result.sizes = {
            "output_mp4_kb": round(out_path.stat().st_size / 1024, 1),
            "srt_kb": round(srt_path.stat().st_size / 1024, 1) if srt_path else 0,
        }
        self.timings["total"] = round(time.time() - self.t0, 1)
        result.timings = dict(self.timings)

        result.ok = verify.ok
        if not verify.ok:
            result.errors = verify.failures

        # 12. reports
        report_path = write_reports(result, self)
        result.report_path = report_path

        # 13. cleanup
        if not self.keep_temp:
            shutil.rmtree(self.work, ignore_errors=True)

        return result


def render_project(config_path: str | Path, out_dir: Optional[str | Path] = None,
                   keep_temp: bool = False, strict: bool = False,
                   dry_run: bool = False, quiet: bool = False) -> RenderResult:
    """End-to-end: config -> validation -> assets -> plan -> render -> verify
    -> report. This is the single entry point used by the CLI and scripts."""
    try:
        cfg = load_config(config_path, strict=strict)
    except ConfigError as e:
        return RenderResult(ok=False, config_path=Path(config_path),
                            errors=[f"Config error: {e}"])
    try:
        if dry_run:
            bpm = cfg.music.bpm
            plan = build_plan(cfg, bpm)
            check_assets(cfg, plan)
            res = RenderResult(ok=True, config_path=cfg.path, plan=plan,
                               warnings=list(cfg.warnings) + plan.notes,
                               dry_run=True)
            res.assets_report = {"scenes": [
                {"scene": s.id, "source": s.source} for s in plan.scenes]}
            return res
        renderer = Renderer(cfg, out_dir=Path(out_dir) if out_dir else None,
                            keep_temp=keep_temp, quiet=quiet)
        return renderer.render()
    except (RenderError, AssetError, ValueError, env.ToolError) as e:
        return RenderResult(ok=False, config_path=Path(config_path),
                            errors=[str(e)], warnings=list(cfg.warnings))
