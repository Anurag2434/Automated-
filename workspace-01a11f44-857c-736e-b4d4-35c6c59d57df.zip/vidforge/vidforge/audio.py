"""Audio: BPM estimation from real audio files, and the final mix.

The mix stage supports background music (file or synthetic), per-scene
narration files placed at their final-timeline offsets, volume in dB, and
fade-in/out. Narration audio requires either user-provided files or an AI TTS
provider (see vidforge.ai); when neither exists the mix proceeds with music
only and a warning is recorded - never a silent failure.
"""

from __future__ import annotations

import array
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from . import env, synth
from .config import ProjectConfig
from .scenes import ScenePlan


# ---------------------------------------------------------------------------
# BPM estimation (onset-envelope autocorrelation, no third-party deps)
# ---------------------------------------------------------------------------

_ENV_SR = 11025
_ENV_WINDOW = 256


def _decode_mono_pcm(path: str, ffmpeg: str, max_seconds: float = 120.0) -> array.array:
    """Decode up to `max_seconds` of audio to mono s16le PCM via ffmpeg."""
    proc = subprocess.run(
        [ffmpeg, "-hide_banner", "-loglevel", "error",
         "-t", str(max_seconds), "-i", path,
         "-ac", "1", "-ar", str(_ENV_SR), "-f", "s16le", "-"],
        capture_output=True, timeout=300, check=False,
    )
    if proc.returncode != 0 or not proc.stdout:
        raise RuntimeError(
            f"Could not decode audio '{path}': {proc.stderr.decode('utf-8', 'replace')[:200]}"
        )
    arr = array.array("h")
    arr.frombytes(proc.stdout[: len(proc.stdout) // 2 * 2])
    if sys.byteorder == "big":
        arr.byteswap()
    return arr


def _onset_envelope(pcm: array.array) -> Tuple[List[float], float]:
    """RMS energy envelope and positive-difference onset strength."""
    win = _ENV_WINDOW
    n_windows = len(pcm) // win
    rms: List[float] = []
    for w in range(n_windows):
        acc = 0
        base = w * win
        for i in range(base, base + win):
            acc += pcm[i] * pcm[i]
        rms.append((acc / win) ** 0.5)
    onset: List[float] = [0.0]
    for i in range(1, len(rms)):
        onset.append(max(0.0, rms[i] - rms[i - 1]))
    return onset, _ENV_SR / win


def estimate_bpm(path: str, caps: Optional[env.Caps] = None,
                 min_bpm: float = 60.0, max_bpm: float = 200.0) -> float:
    """Estimate tempo (BPM) of an audio file via onset autocorrelation.

    Raises RuntimeError if the file cannot be decoded or no plausible tempo
    is found. Accuracy target: within ~2% for rhythmic material.
    """
    caps = caps or env.get_caps()
    pcm = _decode_mono_pcm(path, caps.ffmpeg)
    if len(pcm) < _ENV_SR:  # < 1 second of audio
        raise RuntimeError(f"Audio '{path}' is too short for tempo analysis.")
    onset, rate = _onset_envelope(pcm)
    mean = sum(onset) / len(onset) or 1e-9
    onset = [o / mean for o in onset]

    lag_min = max(2, int(60.0 / max_bpm * rate))
    lag_max = int(60.0 / min_bpm * rate)
    scores = {}
    for lag in range(lag_min, lag_max + 1):
        score = 0.0
        for i in range(lag, len(onset)):
            score += onset[i] * onset[i - lag]
        scores[lag] = score / (len(onset) - lag)
    if not scores:
        raise RuntimeError(f"No tempo found in '{path}'.")
    best_lag = max(scores, key=scores.get)
    best_score = scores[best_lag]

    def _fold(b: float) -> float:
        while b < min_bpm:
            b *= 2
        while b > max_bpm:
            b /= 2
        return b

    # Tempo-octave disambiguation: autocorrelation happily locks onto 2x the
    # beat period. Consider the best lag plus its octave neighbours, keep the
    # ones whose score is >= 60% of the best, and prefer the tempo closest to
    # 120 BPM (the common pop/edit range). An explicit `bpm` in the config
    # always overrides estimation, so this heuristic is safe to use.
    import math
    candidates = set()
    for lag in {best_lag,
                max(2, round(best_lag / 2)),
                round(best_lag * 2)}:
        if lag in scores and scores[lag] >= 0.6 * best_score:
            candidates.add(_fold(60.0 * rate / lag))
    if not candidates:
        candidates = {_fold(60.0 * rate / best_lag)}
    bpm = min(candidates, key=lambda b: abs(math.log2(b / 120.0)))
    return round(bpm, 1)


# ---------------------------------------------------------------------------
# Final mix
# ---------------------------------------------------------------------------

@dataclass
class AudioMixResult:
    path: Optional[Path]
    used_music: bool = False
    music_source: str = ""
    narration_clips: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)


def build_audio_track(cfg: ProjectConfig, plan: ScenePlan, workdir: Path,
                      caps: Optional[env.Caps] = None) -> AudioMixResult:
    """Build the full-length audio track as a WAV, or None if no audio.

    Music: 'synthetic' generates a placeholder bed at the configured BPM;
    a path uses that file (looped/trimmed to the final duration).
    Narration: per-scene files from <narration.dir>/<scene_id>.<ext>.
    """
    caps = caps or env.get_caps()
    result = AudioMixResult(path=None)
    total = plan.final_total

    music_path: Optional[Path] = None
    bpm = plan.bpm
    if cfg.music.source not in ("none", "") and cfg.audio_enabled:
        if cfg.music.source == "synthetic":
            if not bpm:
                bpm = 120.0
                result.warnings.append(
                    "Synthetic music without a BPM: defaulting to 120 BPM."
                )
            music_path = workdir / "music_synth.wav"
            synth.synth_music_bed(music_path, total + 0.5, bpm)
            result.music_source = f"synthetic ({bpm:g} BPM placeholder)"
        else:
            from .assets import resolve_audio_source  # local import to avoid cycle
            music_path = resolve_audio_source(cfg.music.source, cfg)
            result.music_source = f"file:{music_path.name}"
    if music_path is not None:
        result.used_music = True

    # Narration files per scene, offset by final-timeline start.
    narration: List[Tuple[Path, float]] = []
    if cfg.narration.enabled and cfg.audio_enabled:
        from .assets import find_narration_file
        missing = []
        for sc in plan.scenes:
            if not (sc.narration or sc.subtitle):
                continue
            f = find_narration_file(cfg, sc.id)
            if f is None:
                missing.append(sc.id)
            else:
                narration.append((f, sc.final_start))
                result.narration_clips.append(f"{sc.id}:{f.name}")
        if missing:
            result.warnings.append(
                f"Narration enabled but no audio file found for scene(s) "
                f"{missing}. Expected <{cfg.narration.dir}/{''}>/<scene_id>.wav|mp3|... "
                f"next to the config. Those scenes will have subtitles only."
            )

    if music_path is None and not narration:
        result.warnings.append(
            "No music and no narration audio: the output will have no audio track."
        )
        return result

    # Assemble the ffmpeg mix command.
    cmd = [caps.ffmpeg, "-y", "-hide_banner", "-loglevel", "error"]
    music_is_short = False
    if music_path is not None:
        info = env.probe_media(str(music_path), caps)
        mdur = (info or {}).get("duration") or 0.0
        if mdur + 0.05 < total:
            cmd += ["-stream_loop", "-1"]
            music_is_short = True
        cmd += ["-i", str(music_path)]
    for f, _ in narration:
        cmd += ["-i", str(f)]

    parts: List[str] = []
    mix_labels: List[str] = []
    idx = 0
    if music_path is not None:
        chain = [
            f"atrim=0:{total:.3f}", "asetpts=PTS-STARTPTS",
            f"volume={cfg.music.volume_db}dB",
        ]
        if cfg.music.fade_in > 0:
            chain.append(f"afade=t=in:st=0:d={cfg.music.fade_in:.3f}")
        if cfg.music.fade_out > 0:
            chain.append(
                f"afade=t=out:st={max(0.0, total - cfg.music.fade_out):.3f}"
                f":d={cfg.music.fade_out:.3f}"
            )
        chain.append("aformat=sample_fmts=fltp:channel_layouts=stereo:sample_rates=44100")
        parts.append(f"[{idx}:a]" + ",".join(chain) + "[m]")
        mix_labels.append("[m]")
        idx += 1
    for f, offset in narration:
        delay_ms = int(round(offset * 1000))
        chain = [
            f"adelay={delay_ms}:all=1",
            f"volume={cfg.narration.volume_db}dB",
            "aformat=sample_fmts=fltp:channel_layouts=stereo:sample_rates=44100",
        ]
        parts.append(f"[{idx}:a]" + ",".join(chain) + f"[n{idx}]")
        mix_labels.append(f"[n{idx}]")
        idx += 1

    n = len(mix_labels)
    if n == 1:
        parts.append(mix_labels[0] + "anull[aout]")
    else:
        normalize = ":normalize=0" if caps.amix_normalize else ""
        parts.append("".join(mix_labels) + f"amix=inputs={n}:duration=first"
                     f"{normalize}[aout]")

    out_path = workdir / "audio_mix.wav"
    cmd += [
        "-filter_complex", ";".join(parts),
        "-map", "[aout]", "-t", f"{total:.3f}",
        "-ac", "2", "-ar", "44100", "-c:a", "pcm_s16le", str(out_path),
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if proc.returncode != 0:
        raise RuntimeError(
            "Audio mix failed: " + (proc.stderr.strip()[-400:] or "unknown error")
        )
    result.path = out_path
    return result
