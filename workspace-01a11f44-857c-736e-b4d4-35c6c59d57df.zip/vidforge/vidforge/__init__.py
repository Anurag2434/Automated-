"""vidforge — lightweight, AI-optional video production pipeline.

Two workflows share components but keep separate defaults:

- anime_reel  : 9:16 vertical, 15-60 s, beat-synced cuts, effects, captions
- documentary : 16:9 landscape, 15 s-60 min, narration/subtitles, titles

Usage:  python3 -m vidforge <command> ...
"""

__version__ = "0.1.0"

from .config import load_config, ConfigError  # noqa: F401
from .scenes import build_plan  # noqa: F401
from .render import render_project, RenderError  # noqa: F401
