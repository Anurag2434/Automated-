"""Synthetic asset generation (pure Python, stdlib only).

Everything produced here is clearly labelled SYNTHETIC TEST material. It
exists so the pipeline can be exercised end-to-end without downloading or
using anyone's footage or music.

- :func:`synth_music_bed`  : a rhythmic placeholder "music" track (kick on
  beats, hats on eighths, a soft chord pad) written as a 44.1 kHz stereo WAV.
- :func:`synth_click_track`: metronome clicks at a given BPM - used to test
  the BPM estimator without any third-party audio library.
"""

from __future__ import annotations

import math
import random
import struct
import wave
from pathlib import Path
from typing import List

SR = 44100


def _write_wav(path: Path, samples: List[int], channels: int = 2) -> None:
    """Write interleaved 16-bit PCM samples to a WAV file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(channels)
        w.setsampwidth(2)
        w.setframerate(SR)
        if channels == 2:
            frames = struct.pack("<%dh" % len(samples), *samples)
        else:
            frames = struct.pack("<%dh" % len(samples), *samples)
        w.writeframes(frames)


def synth_music_bed(path: str | Path, duration: float, bpm: float,
                    seed: int = 42) -> Path:
    """Generate a synthetic placeholder music bed with a clear beat.

    This is NOT music - it is a test tone arrangement (kick + hats + pad)
    intended to exercise beat sync, mixing and fades.
    """
    path = Path(path)
    n = int(duration * SR)
    beat = 60.0 / bpm
    rng = random.Random(seed)

    # Precompute one kick cycle and one hat cycle as short decay tables.
    kick_len = int(min(0.25, beat * 0.8) * SR)
    kick = [
        int(24000 * math.sin(2 * math.pi * 52 * i / SR) * math.exp(-i / (SR * 0.045)))
        for i in range(kick_len)
    ]
    hat_len = int(0.05 * SR)
    hat = [
        int(6000 * (rng.random() * 2 - 1) * math.exp(-i / (SR * 0.008)))
        for _ in range(1)
        for i in range(hat_len)
    ]

    pad_freqs = (220.0, 277.18, 329.63)  # A major-ish triad, deliberately bland
    out: List[int] = [0] * n
    for i in range(n):
        t = i / SR
        # chord pad with slow tremolo
        v = 0.13 * (0.6 + 0.4 * math.sin(2 * math.pi * 0.25 * t))
        pad = v * sum(math.sin(2 * math.pi * f * t) for f in pad_freqs)
        # sidechain-style duck so the kick is audible
        beat_phase = (t % beat) / beat
        duck = 1.0 - 0.5 * math.exp(-beat_phase * 14)
        s = pad * duck
        out[i] = int(max(-30000, min(30000, s * 32767)))

    # Kick on every beat.
    for b in range(int(duration / beat) + 1):
        start = int(b * beat * SR)
        for i, kv in enumerate(kick):
            j = start + i
            if j >= n:
                break
            out[j] = max(-32000, min(32000, out[j] + kv))

    # Hats on eighth notes (quieter, off-beats).
    eighth = beat / 2
    for e in range(int(duration / eighth) + 1):
        if e % 2 == 0:
            continue
        start = int(e * eighth * SR)
        for i, hv in enumerate(hat):
            j = start + i
            if j >= n:
                break
            out[j] = max(-32000, min(32000, out[j] + hv // 2))

    # Stereo: duplicate channel.
    stereo: List[int] = [0] * (n * 2)
    for i, v in enumerate(out):
        stereo[2 * i] = v
        stereo[2 * i + 1] = v
    _write_wav(path, stereo, channels=2)
    return path


def synth_click_track(path: str | Path, duration: float, bpm: float,
                      freq: int = 1000) -> Path:
    """Generate a metronome click track (used to test BPM estimation)."""
    path = Path(path)
    n = int(duration * SR)
    out: List[int] = [0] * n
    beat = 60.0 / bpm
    click_len = int(0.03 * SR)
    for b in range(int(duration / beat) + 1):
        start = int(b * beat * SR)
        for i in range(click_len):
            j = start + i
            if j >= n:
                break
            out[j] = int(20000 * math.sin(2 * math.pi * freq * i / SR)
                         * math.exp(-i / (SR * 0.006)))
    _write_wav(path, out, channels=1)
    return path


def synth_tone(path: str | Path, duration: float, freq: float = 440.0,
               volume: float = 0.25) -> Path:
    """Generate a plain sine tone (test signal for mux tests)."""
    path = Path(path)
    n = int(duration * SR)
    out = [
        int(volume * 32767 * math.sin(2 * math.pi * freq * i / SR))
        for i in range(n)
    ]
    _write_wav(path, out, channels=1)
    return path
