"""Project configuration: loading, defaults, and validation.

A project is described by a JSON file. Two project types are supported and
they deliberately have different defaults and bounds:

- ``anime_reel``     : vertical 9:16, 5-90 s, beat-synced editing defaults.
- ``documentary``    : landscape 16:9, 5-3600 s, narration/subtitle defaults.

Scene durations may be explicit or ``null`` (auto-distributed). If every scene
has an explicit duration, the sum must match the target duration.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

PROJECT_TYPES = ("anime_reel", "documentary")

# Informational presets; any duration inside DURATION_BOUNDS is accepted.
CANONICAL_DURATIONS = {
    "anime_reel": (15, 30, 45, 60),
    "documentary": (15, 30, 45, 60, 90, 180, 240, 900, 1800, 2700, 3600),
}
DURATION_BOUNDS = {"anime_reel": (5, 90), "documentary": (5, 3600)}
DEFAULT_RESOLUTION = {"anime_reel": (720, 1280), "documentary": (1280, 720)}
DEFAULT_ASPECT = {"anime_reel": "9:16", "documentary": "16:9"}

TRANSITIONS_PER_CLIP = ("cut", "fade", "fadewhite")
XFADE_TRANSITIONS = {
    # name used in config -> xfade transition name
    "dissolve": "fade",
    "wipeleft": "wipeleft",
    "wiperight": "wiperight",
    "slideleft": "slideleft",
    "slideright": "slideright",
    "circleopen": "circleopen",
    "circleclose": "circleclose",
    "pixelize": "pixelize",
}
ALL_TRANSITIONS = TRANSITIONS_PER_CLIP + tuple(XFADE_TRANSITIONS)

EFFECTS = ("zoom", "shake", "grain", "mirror", "beat_pulse")
STYLE_PRESETS = ("clean", "vivid", "muted", "noir", "retro")

_KNOWN_TOP = {"project", "render", "style", "audio", "subtitles", "scenes", "ai"}
_KNOWN_PROJECT = {"name", "type", "duration", "aspect", "resolution", "fps",
                  "language", "assets_dir"}
_KNOWN_RENDER = {"crf", "preset", "keep_temp", "transition_duration", "fade_out"}
_KNOWN_STYLE = {"preset", "palette", "beat_pulse"}
_KNOWN_AUDIO = {"enabled", "beat_sync", "music", "narration"}
_KNOWN_MUSIC = {"source", "bpm", "volume_db", "fade_in", "fade_out"}
_KNOWN_NARRATION = {"enabled", "language", "volume_db", "dir"}
_KNOWN_SUBTITLES = {"enabled", "burn", "font_size", "position"}
_KNOWN_SCENE = {"id", "title", "duration", "source", "visual", "subtitle",
                "narration", "transition_in", "effect", "audio_cue"}
_KNOWN_AI = {"enabled", "provider", "model"}


class ConfigError(ValueError):
    """Raised for invalid project configuration."""


def _require(cond: bool, msg: str) -> None:
    if not cond:
        raise ConfigError(msg)


def _num(value: Any, name: str) -> float:
    _require(
        isinstance(value, (int, float)) and not isinstance(value, bool),
        f"'{name}' must be a number, got {value!r}",
    )
    return float(value)


def _warn_unknown(d: dict, known: set, where: str, warnings: List[str]) -> None:
    for key in d:
        if key not in known and not key.startswith("_"):
            # keys with a leading underscore are treated as comments
            warnings.append(f"Unknown key '{where}.{key}' (ignored).")


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------

@dataclass
class SceneCfg:
    id: str
    title: str = ""
    duration: Optional[float] = None  # None -> auto-distribute
    source: str = "synthetic"         # "synthetic", "synthetic:<label>", or a path
    visual: str = "gradient"          # synthetic look: "gradient" | "flat"
    subtitle: str = ""
    narration: str = ""
    transition_in: str = "cut"
    effect: Optional[str] = None
    audio_cue: Optional[str] = None


@dataclass
class ProjectSpec:
    name: str
    type: str
    duration: float
    fps: int
    width: int
    height: int
    aspect: str
    language: str
    assets_dir: str

    @property
    def is_reel(self) -> bool:
        return self.type == "anime_reel"


@dataclass
class MusicSpec:
    source: str = "synthetic"   # "synthetic" | "none" | path to audio file
    bpm: Optional[float] = None
    volume_db: float = -10.0
    fade_in: float = 0.5
    fade_out: float = 1.0


@dataclass
class NarrationSpec:
    enabled: bool = False
    language: str = "en"
    volume_db: float = 0.0
    dir: str = "narration"      # per-scene files: <dir>/<scene_id>.wav ...


@dataclass
class SubtitleSpec:
    enabled: bool = True
    burn: bool = True
    font_size: int = 30
    position: str = "bottom"    # "bottom" | "lower_third" | "top"


@dataclass
class StyleSpec:
    preset: str = "clean"
    palette: Tuple[str, ...] = ("#ff2d78", "#7a2dff", "#12e6c8", "#ffb020")
    beat_pulse: bool = False


@dataclass
class RenderSpec:
    crf: int = 26
    preset: str = "veryfast"
    keep_temp: bool = False
    transition_duration: float = 0.5
    fade_out: float = 0.8


@dataclass
class AISpec:
    enabled: bool = False
    provider: str = "null"
    model: str = ""


@dataclass
class ProjectConfig:
    path: Path
    project: ProjectSpec
    render: RenderSpec
    style: StyleSpec
    music: MusicSpec
    narration: NarrationSpec
    subtitles: SubtitleSpec
    audio_enabled: bool
    beat_sync: bool
    ai: AISpec
    scenes: List[SceneCfg]
    warnings: List[str] = field(default_factory=list)

    def add_warning(self, msg: str) -> None:
        if msg not in self.warnings:
            self.warnings.append(msg)


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

def load_config(path: str | Path, strict: bool = False) -> ProjectConfig:
    """Load and validate a project JSON file.

    Raises ConfigError with an actionable message on invalid input.
    In strict mode, warnings (e.g. unknown keys) become errors.
    """
    path = Path(path)
    if not path.is_file():
        raise ConfigError(f"Config file not found: {path}")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ConfigError(f"Config file {path} is not valid JSON: {e}") from e
    _require(isinstance(raw, dict), f"Config root must be a JSON object, got {type(raw).__name__}")
    cfg = _build(raw, path)
    if strict and cfg.warnings:
        raise ConfigError(f"Strict mode: {len(cfg.warnings)} warning(s): " + "; ".join(cfg.warnings))
    return cfg


def _build(raw: dict, path: Path) -> ProjectConfig:
    warnings: List[str] = []
    _warn_unknown(raw, _KNOWN_TOP, "root", warnings)

    proj = raw.get("project")
    _require(isinstance(proj, dict), "Missing required section 'project'.")
    _warn_unknown(proj, _KNOWN_PROJECT, "project", warnings)

    ptype = proj.get("type")
    _require(ptype in PROJECT_TYPES,
             f"project.type must be one of {PROJECT_TYPES}, got {ptype!r}.")

    duration = _num(proj.get("duration"), "project.duration")
    lo, hi = DURATION_BOUNDS[ptype]
    _require(lo <= duration <= hi,
             f"project.duration {duration:g}s is out of bounds for '{ptype}' "
             f"({lo}-{hi}s). Canonical presets: {CANONICAL_DURATIONS[ptype]}.")

    name = str(proj.get("name") or Path(path).stem)
    _require(bool(name.strip()), "project.name must be a non-empty string.")

    aspect = str(proj.get("aspect") or DEFAULT_ASPECT[ptype])

    res = proj.get("resolution")
    if res is None:
        width, height = DEFAULT_RESOLUTION[ptype]
    else:
        _require(isinstance(res, list) and len(res) == 2,
                 f"project.resolution must be [width, height], got {res!r}.")
        try:
            width, height = int(res[0]), int(res[1])
        except (TypeError, ValueError):
            raise ConfigError(f"project.resolution must be integers, got {res!r}.")
    _require(width >= 128 and height >= 128, f"Resolution {width}x{height} is too small (min 128).")
    _require(width % 2 == 0 and height % 2 == 0,
             f"Resolution {width}x{height}: both dimensions must be even (H.264 requirement).")
    # Aspect consistency check (warning only - flexible by design).
    target_ratio = {"9:16": 9 / 16, "16:9": 16 / 9}.get(aspect)
    if target_ratio and abs((width / height) - target_ratio) > 0.02:
        warnings.append(
            f"project.resolution {width}x{height} does not match aspect "
            f"{aspect}; the rendered file will use {width}x{height}."
        )
    if ptype == "anime_reel" and width >= height:
        warnings.append("anime_reel is normally vertical (width < height); "
                        f"got {width}x{height}.")
    if ptype == "documentary" and width <= height:
        warnings.append("documentary is normally landscape (width > height); "
                        f"got {width}x{height}.")

    fps = proj.get("fps", 30)
    _require(isinstance(fps, int) and not isinstance(fps, bool) and 10 <= fps <= 60,
             f"project.fps must be an integer in 10-60, got {fps!r}.")

    language = str(proj.get("language", "en"))
    _require(bool(re_ok_language(language)),
             f"project.language {language!r} does not look like a BCP-47 tag (e.g. 'en', 'pt-BR').")

    assets_dir = str(proj.get("assets_dir", "assets"))

    # --- render -----------------------------------------------------------
    r = raw.get("render", {}) or {}
    _require(isinstance(r, dict), "'render' must be an object.")
    _warn_unknown(r, _KNOWN_RENDER, "render", warnings)
    crf = int(r.get("crf", 26))
    _require(18 <= crf <= 34, f"render.crf must be 18-34, got {crf}.")
    preset = str(r.get("preset", "veryfast"))
    transition_duration = _num(r.get("transition_duration", 0.5), "render.transition_duration")
    _require(0.1 <= transition_duration <= 3.0,
             f"render.transition_duration must be 0.1-3.0s, got {transition_duration}.")
    fade_out = _num(r.get("fade_out", 0.8), "render.fade_out")
    _require(0 <= fade_out <= 5.0, f"render.fade_out must be 0-5s, got {fade_out}.")

    # --- style ------------------------------------------------------------
    s = raw.get("style", {}) or {}
    _require(isinstance(s, dict), "'style' must be an object.")
    _warn_unknown(s, _KNOWN_STYLE, "style", warnings)
    preset_style = str(s.get("preset", "clean"))
    _require(preset_style in STYLE_PRESETS,
             f"style.preset must be one of {STYLE_PRESETS}, got {preset_style!r}.")
    palette_raw = s.get("palette", [])
    _require(isinstance(palette_raw, list), "style.palette must be a list of colors.")
    palette = []
    for c in palette_raw:
        _require(isinstance(c, str) and re_ok_color(c),
                 f"style.palette entry {c!r} must be '#RRGGBB'.")
        palette.append(c)
    if not palette:
        palette = ["#ff2d78", "#7a2dff", "#12e6c8", "#ffb020"]

    # --- audio ------------------------------------------------------------
    a = raw.get("audio", {}) or {}
    _require(isinstance(a, dict), "'audio' must be an object.")
    _warn_unknown(a, _KNOWN_AUDIO, "audio", warnings)
    audio_enabled = bool(a.get("enabled", True))
    beat_sync = bool(a.get("beat_sync", ptype == "anime_reel"))

    m = a.get("music", {}) or {}
    _require(isinstance(m, dict), "'audio.music' must be an object.")
    _warn_unknown(m, _KNOWN_MUSIC, "audio.music", warnings)
    music_source = str(m.get("source", "synthetic"))
    _require(music_source in ("synthetic", "none") or bool(music_source.strip()),
             "audio.music.source must be 'synthetic', 'none', or a file path.")
    bpm = m.get("bpm")
    if bpm is not None:
        bpm = _num(bpm, "audio.music.bpm")
        _require(40 <= bpm <= 220, f"audio.music.bpm must be 40-220, got {bpm}.")
    music_vol = _num(m.get("volume_db", -10.0), "audio.music.volume_db")
    _require(-48 <= music_vol <= 6, f"audio.music.volume_db must be -48..6 dB, got {music_vol}.")
    mfi = _num(m.get("fade_in", 0.5), "audio.music.fade_in")
    mfo = _num(m.get("fade_out", 1.0), "audio.music.fade_out")
    _require(0 <= mfi <= duration / 2, "audio.music.fade_in exceeds half the project duration.")
    _require(0 <= mfo <= duration / 2, "audio.music.fade_out exceeds half the project duration.")

    n = a.get("narration", {}) or {}
    _require(isinstance(n, dict), "'audio.narration' must be an object.")
    _warn_unknown(n, _KNOWN_NARRATION, "audio.narration", warnings)
    narr_lang = str(n.get("language", language))
    narr_vol = _num(n.get("volume_db", 0.0), "audio.narration.volume_db")
    _require(-24 <= narr_vol <= 12, f"audio.narration.volume_db must be -24..12 dB, got {narr_vol}.")

    # --- subtitles ----------------------------------------------------------
    sub = raw.get("subtitles", {}) or {}
    _require(isinstance(sub, dict), "'subtitles' must be an object.")
    _warn_unknown(sub, _KNOWN_SUBTITLES, "subtitles", warnings)
    sub_pos = str(sub.get("position", "bottom" if ptype == "documentary" else "lower_third"))
    _require(sub_pos in ("bottom", "lower_third", "top"),
             f"subtitles.position must be bottom|lower_third|top, got {sub_pos!r}.")
    font_size = int(sub.get("font_size", 30 if ptype == "documentary" else 34))
    _require(10 <= font_size <= 96, f"subtitles.font_size must be 10-96, got {font_size}.")

    # --- ai -----------------------------------------------------------------
    ai = raw.get("ai", {}) or {}
    _require(isinstance(ai, dict), "'ai' must be an object.")
    _warn_unknown(ai, _KNOWN_AI, "ai", warnings)

    # --- scenes ---------------------------------------------------------------
    scenes_raw = raw.get("scenes")
    _require(isinstance(scenes_raw, list) and len(scenes_raw) >= 1,
             "'scenes' must be a non-empty list.")
    scenes: List[SceneCfg] = []
    seen_ids = set()
    sum_fixed = 0.0
    n_auto = 0
    for i, sc in enumerate(scenes_raw):
        _require(isinstance(sc, dict), f"scenes[{i}] must be an object.")
        _warn_unknown(sc, _KNOWN_SCENE, f"scenes[{i}]", warnings)
        sid = str(sc.get("id") or f"scene_{i + 1}")
        _require(sid not in seen_ids, f"Duplicate scene id '{sid}' (scenes[{i}]).")
        seen_ids.add(sid)
        d = sc.get("duration")
        if d is not None:
            d = _num(d, f"scenes[{i}].duration")
            _require(d >= 0.5, f"Scene '{sid}': duration must be >= 0.5s, got {d}s.")
            _require(d <= duration, f"Scene '{sid}': duration {d}s exceeds project duration {duration:g}s.")
            sum_fixed += d
        else:
            n_auto += 1
        transition = str(sc.get("transition_in", "cut"))
        _require(transition in ALL_TRANSITIONS,
                 f"Scene '{sid}': transition_in {transition!r} not supported. "
                 f"Use one of {ALL_TRANSITIONS}.")
        effect = sc.get("effect")
        _require(effect is None or effect in EFFECTS,
                 f"Scene '{sid}': effect {effect!r} not supported. Use one of {EFFECTS}.")
        visual = str(sc.get("visual", "gradient"))
        _require(visual in ("gradient", "flat"),
                 f"Scene '{sid}': visual {visual!r} must be 'gradient' or 'flat'.")
        if sc.get("audio_cue"):
            warnings.append(f"Scene '{sid}': audio_cue is reserved and not implemented yet; ignored.")
        scenes.append(SceneCfg(
            id=sid,
            title=str(sc.get("title", "")),
            duration=d,
            source=str(sc.get("source", "synthetic")),
            visual=visual,
            subtitle=str(sc.get("subtitle", "")),
            narration=str(sc.get("narration", "")),
            transition_in=transition,
            effect=effect,
            audio_cue=sc.get("audio_cue"),
        ))

    _require(sum_fixed <= duration + 0.05,
             f"Scenes with fixed durations total {sum_fixed:.2f}s, which exceeds the "
             f"project duration {duration:g}s. Reduce scene durations or set some to null.")
    if n_auto == 0:
        _require(abs(sum_fixed - duration) <= 0.05,
                 f"Scene durations sum to {sum_fixed:.2f}s but project.duration is "
                 f"{duration:g}s (tolerance 0.05s). Set some scene durations to null "
                 "to auto-distribute the remaining time, or fix the numbers.")
    else:
        remaining = duration - sum_fixed
        _require(remaining / n_auto >= 0.5,
                 f"Not enough time left for {n_auto} scene(s) without explicit duration: "
                 f"{remaining:.2f}s remaining, need >= {0.5 * n_auto:.2f}s.")

    if scenes[0].transition_in != "cut":
        warnings.append("scenes[0].transition_in is ignored (nothing precedes the first scene).")

    return ProjectConfig(
        path=path,
        project=ProjectSpec(
            name=name, type=ptype, duration=duration, fps=fps,
            width=width, height=height, aspect=aspect,
            language=language, assets_dir=assets_dir,
        ),
        render=RenderSpec(crf=crf, preset=preset,
                          keep_temp=bool(r.get("keep_temp", False)),
                          transition_duration=transition_duration,
                          fade_out=fade_out),
        style=StyleSpec(preset=preset_style, palette=tuple(palette),
                        beat_pulse=bool(s.get("beat_pulse", False))),
        music=MusicSpec(source=music_source, bpm=bpm, volume_db=music_vol,
                        fade_in=mfi, fade_out=mfo),
        narration=NarrationSpec(enabled=bool(n.get("enabled", False)),
                                language=narr_lang, volume_db=narr_vol,
                                dir=str(n.get("dir", "narration"))),
        subtitles=SubtitleSpec(enabled=bool(sub.get("enabled", True)),
                               burn=bool(sub.get("burn", True)),
                               font_size=font_size, position=sub_pos),
        audio_enabled=audio_enabled,
        beat_sync=beat_sync,
        ai=AISpec(enabled=bool(ai.get("enabled", False)),
                  provider=str(ai.get("provider", "null")),
                  model=str(ai.get("model", ""))),
        scenes=scenes,
        warnings=warnings,
    )


def re_ok_language(tag: str) -> bool:
    import re
    return bool(re.fullmatch(r"[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*", tag))


def re_ok_color(c: str) -> bool:
    import re
    return bool(re.fullmatch(r"#[0-9A-Fa-f]{6}", c))
