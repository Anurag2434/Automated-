"""The default provider: no AI at all.

Guarantees the system is fully functional offline. Every method raises
AIDisabledError with instructions for enabling a real provider.
"""

from __future__ import annotations

from .base import AIDisabledError, AIProvider


class NullProvider(AIProvider):
    name = "null"

    def capabilities(self) -> dict:
        return {k: False for k in
                ("scriptwriting", "scene_descriptions", "narration_tts",
                 "image_generation", "video_generation")}

    def generate_script(self, brief, target_duration, project_type):
        raise AIDisabledError(
            "AI is disabled (provider 'null'). Use `vidforge draft` for the "
            "offline template scriptwriter, or configure a provider "
            "(see README 'AI integration')."
        )

    def generate_narration_audio(self, text, out_path, language="en"):
        raise AIDisabledError(
            "No TTS provider configured. Provide narration files as "
            "<narration>/<scene_id>.wav or implement an AIProvider."
        )

    def generate_image(self, prompt, out_path, width=1280, height=720):
        raise AIDisabledError("No image-generation provider configured.")

    def generate_video(self, prompt, out_path, duration=4.0):
        raise AIDisabledError("No video-generation provider configured.")
