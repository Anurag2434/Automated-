"""Optional AI integrations.

Nothing in the core rendering pipeline calls AI. Providers are pluggable via
the ``vidforge.ai.base.AIProvider`` interface; the renderer works entirely
with user-provided assets or synthetic test assets when no provider exists.

Enable explicitly with ``vidforge draft --ai`` (or set ``ai.enabled`` in a
config). No credentials are read, logged, or required unless you opt in.
"""

from .base import AIProvider, AICapabilityError, AIDisabledError
from .null_provider import NullProvider
from .offline import draft_project_offline


def get_provider(name: str = "", model: str = "") -> AIProvider:
    """Resolve a provider by name.

    Known providers: "null" (default, no AI), "openai_compat" (any
    OpenAI-compatible REST API; requires OPENAI_API_KEY in the environment).
    """
    name = (name or "null").strip().lower()
    if name in ("", "null", "none", "disabled"):
        return NullProvider()
    if name in ("openai", "openai_compat", "openai-compatible"):
        from .openai_compat import OpenAICompatProvider  # lazy import
        return OpenAICompatProvider(model=model)
    raise ValueError(
        f"Unknown AI provider '{name}'. Available: null, openai_compat."
    )


__all__ = [
    "AIProvider", "AICapabilityError", "AIDisabledError",
    "NullProvider", "get_provider", "draft_project_offline",
]
