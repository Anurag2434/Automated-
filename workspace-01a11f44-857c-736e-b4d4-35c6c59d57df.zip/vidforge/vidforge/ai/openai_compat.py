"""OpenAI-compatible REST provider (optional; never used by default).

Works with any endpoint that implements the OpenAI chat-completions schema
(api.openai.com, OpenRouter, LM Studio, vLLM, ...). Credentials come from
environment variables and are never printed:

- ``OPENAI_API_KEY``   (required to enable)
- ``OPENAI_BASE_URL``  (optional, default https://api.openai.com/v1)

Cost control: requests are bounded (max_tokens, timeout, one attempt).
Image/video generation support depends on the endpoint and is NOT exercised
by the test suite — see TEST_REPORT.md for what was actually tested.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

from .base import AICapabilityError, AIDisabledError, AIProvider

_TIMEOUT = 60
_MAX_TOKENS = 2000


class OpenAICompatProvider(AIProvider):
    name = "openai_compat"

    def __init__(self, model: str = "", base_url: Optional[str] = None,
                 api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.base_url = (base_url or os.environ.get("OPENAI_BASE_URL")
                         or "https://api.openai.com/v1").rstrip("/")
        self.model = model or os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
        if not self.api_key:
            raise AIDisabledError(
                "openai_compat selected but OPENAI_API_KEY is not set. "
                "Export it (value never printed by vidforge) or pick another provider."
            )

    def capabilities(self) -> dict:
        return {
            "scriptwriting": True,
            "scene_descriptions": True,
            "narration_tts": False,   # endpoint-dependent, not implemented here
            "image_generation": True, # endpoint-dependent, UNTESTED in this build
            "video_generation": False,
        }

    # ------------------------------------------------------------------
    def _post(self, path: str, payload: dict) -> dict:
        req = urllib.request.Request(
            self.base_url + path,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", "replace")[:300]
            raise AICapabilityError(
                f"API error {e.code} from {self.base_url}{path}: {body}"
            ) from e
        except (urllib.error.URLError, TimeoutError) as e:
            raise AICapabilityError(f"API unreachable: {e}") from e

    def _chat(self, system: str, user: str) -> str:
        data = self._post("/chat/completions", {
            "model": self.model,
            "max_tokens": _MAX_TOKENS,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
        })
        try:
            return data["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            raise AICapabilityError(f"Unexpected API response shape: {e}") from e

    # ------------------------------------------------------------------
    def generate_script(self, brief: str, target_duration: float,
                        project_type: str) -> dict:
        system = (
            "You are a video script planner. Reply with ONLY a JSON object: "
            '{"scenes": [{"id", "title", "duration", "narration", "subtitle", '
            '"transition_in"}]}. Durations are seconds and must sum to '
            f"{target_duration:g}. transitions: cut|fade|fadewhite|dissolve|"
            "wipeleft|slideright|circleopen. Keep narration lines short enough "
            "to read as on-screen captions."
        )
        raw = self._chat(system, f"Project type: {project_type}\nBrief: {brief}")
        try:
            start = raw.find("{")
            end = raw.rfind("}") + 1
            parsed = json.loads(raw[start:end])
            parsed.setdefault("scenes", [])
            return parsed
        except json.JSONDecodeError as e:
            raise AICapabilityError(f"Model did not return JSON: {e}") from e

    def generate_image(self, prompt: str, out_path: str | Path,
                       width: int = 1280, height: int = 720) -> Path:
        out_path = Path(out_path)
        data = self._post("/images/generations", {
            "model": os.environ.get("OPENAI_IMAGE_MODEL", "gpt-image-1"),
            "prompt": prompt,
            "size": "1024x1024",
            "n": 1,
        })
        try:
            b64 = data["data"][0]["b64_json"]
        except (KeyError, IndexError) as e:
            raise AICapabilityError(
                f"Endpoint did not return b64 image data: {e}"
            ) from e
        import base64
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(base64.b64decode(b64))
        return out_path

    def generate_narration_audio(self, text, out_path, language="en"):
        raise AICapabilityError(
            "openai_compat: TTS not wired up in this prototype (extend with a "
            "POST /audio/speech call; see README 'Extension points')."
        )

    def generate_video(self, prompt, out_path, duration=4.0):
        raise AICapabilityError(
            "openai_compat: video generation is not supported by this provider stub."
        )
