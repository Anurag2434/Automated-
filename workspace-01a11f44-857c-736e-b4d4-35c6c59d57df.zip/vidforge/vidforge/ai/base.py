"""AIProvider interface.

Every AI capability the system could use is expressed as one method. A new
provider (Anthropic, Gemini, local ComfyUI, an editing co-pilot, ...) is
added by implementing this class and registering it in
``vidforge.ai.get_provider`` — no changes to the renderer are needed.

The core pipeline NEVER calls these methods; they are used only by the
explicit ``vidforge draft --ai`` command and by future tooling.
"""

from __future__ import annotations

import abc
from pathlib import Path
from typing import Optional


class AIDisabledError(RuntimeError):
    """AI was requested but no provider/credential is configured."""


class AICapabilityError(NotImplementedError):
    """The configured provider does not implement this capability."""


class AIProvider(abc.ABC):
    """Pluggable AI backend."""

    name = "abstract"

    #: which methods actually work for this provider
    def capabilities(self) -> dict:
        return {
            "scriptwriting": False,
            "scene_descriptions": False,
            "narration_tts": False,
            "image_generation": False,
            "video_generation": False,
        }

    # --- text -----------------------------------------------------------
    def generate_script(self, brief: str, target_duration: float,
                        project_type: str) -> dict:
        """Return a project-config-style dict with a 'scenes' list."""
        raise AICapabilityError(f"{self.name}: scriptwriting not implemented")

    # --- audio ----------------------------------------------------------
    def generate_narration_audio(self, text: str, out_path: str | Path,
                                 language: str = "en") -> Path:
        """Synthesize speech for `text`; return the audio file path."""
        raise AICapabilityError(f"{self.name}: narration TTS not implemented")

    # --- visuals ----------------------------------------------------------
    def generate_image(self, prompt: str, out_path: str | Path,
                       width: int = 1280, height: int = 720) -> Path:
        raise AICapabilityError(f"{self.name}: image generation not implemented")

    def generate_video(self, prompt: str, out_path: str | Path,
                       duration: float = 4.0) -> Path:
        raise AICapabilityError(f"{self.name}: video generation not implemented")
