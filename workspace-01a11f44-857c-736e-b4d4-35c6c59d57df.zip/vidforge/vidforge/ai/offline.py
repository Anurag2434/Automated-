"""Offline (no-AI) script drafting.

Deterministically scaffolds a project config from a topic and duration.
The output is a TEMPLATE: narration lines are placeholders that the user is
expected to replace. It exists so `vidforge draft` works with zero network,
zero credentials, and zero API cost — and so the AI provider interface can be
compared against a known-good offline baseline.
"""

from __future__ import annotations

from typing import Optional

from ..config import CANONICAL_DURATIONS


def draft_project_offline(project_type: str, topic: str, duration: float,
                          name: Optional[str] = None) -> dict:
    if project_type not in ("anime_reel", "documentary"):
        raise ValueError("project_type must be 'anime_reel' or 'documentary'")
    topic = (topic or "untitled").strip() or "untitled"

    if project_type == "anime_reel":
        scene_count = max(4, min(10, int(duration / 2.5)))
        beats = ["HOOK", "BUILD", "PEAK", "TWIST", "PAYOFF", "OUTRO"]
        scenes = []
        for i in range(scene_count):
            scenes.append({
                "id": f"s{i + 1}",
                "title": beats[i % len(beats)],
                "duration": None,  # auto-distribute
                "source": "synthetic",
                "visual": "gradient",
                "subtitle": f"[replace with your clip] {topic} — beat {i + 1}",
                "transition_in": "cut" if i == 0 else ("dissolve" if i % 3 == 2 else "cut"),
                "effect": "beat_pulse" if i % 2 == 1 else None,
            })
        return {
            "project": {
                "name": name or topic.lower().replace(" ", "_")[:30],
                "type": "anime_reel",
                "duration": duration,
                "fps": 30,
                "language": "en",
            },
            "style": {"preset": "vivid", "beat_pulse": True},
            "audio": {
                "enabled": True,
                "beat_sync": True,
                "music": {"source": "synthetic", "bpm": 128,
                          "volume_db": -10, "fade_in": 0.5, "fade_out": 1.0},
                "narration": {"enabled": False, "language": "en"},
            },
            "subtitles": {"enabled": True, "burn": True, "font_size": 34,
                          "position": "lower_third"},
            "scenes": scenes,
        }

    # documentary
    scene_len = 12.0 if duration <= 120 else (25.0 if duration <= 600 else 45.0)
    scene_count = max(3, min(80, round(duration / scene_len)))
    chapters = [
        ("TITLE: " + topic.upper(), "Opening title card."),
        ("COLD OPEN", "A striking detail or question to pull viewers in."),
        ("CONTEXT", "Where and when does this story take place?"),
        ("ORIGINS", "How did it begin? Introduce the key people or forces."),
        ("ESCALATION", "What complicated the story? Tension builds."),
        ("TURNING POINT", "The moment everything changed."),
        ("CONSEQUENCES", "What happened as a result? Short- and long-term."),
        ("LEGACY", "What remains today? Why it still matters."),
        ("CLOSING", "Wrap up and invite the viewer to reflect or subscribe."),
    ]
    scenes = []
    for i in range(scene_count):
        head, desc = chapters[min(i, len(chapters) - 1)] if i < len(chapters) \
            else chapters[-1]
        if i == 0:
            title, subtitle = head, f"{topic} — a vidforge template documentary"
        elif i == scene_count - 1:
            title, subtitle = "CLOSING", "Thanks for watching."
        else:
            title = head if i < len(chapters) - 1 else "CHAPTER"
            subtitle = f"[TEMPLATE narration — replace] {desc} (scene {i + 1} of {scene_count})"
        scenes.append({
            "id": f"chapter_{i + 1:02d}",
            "title": title,
            "duration": None,
            "source": "synthetic",
            "visual": "gradient",
            "narration": subtitle,
            "subtitle": subtitle,
            "transition_in": "cut" if i == 0 else "fade",
        })
    return {
        "project": {
            "name": name or topic.lower().replace(" ", "_")[:30],
            "type": "documentary",
            "duration": duration,
            "fps": 30,
            "language": "en",
        },
        "style": {"preset": "muted"},
        "audio": {
            "enabled": True,
            "beat_sync": False,
            "music": {"source": "synthetic", "bpm": 90,
                      "volume_db": -16, "fade_in": 1.0, "fade_out": 2.0},
            "narration": {"enabled": True, "language": "en",
                          "dir": "narration"},
        },
        "subtitles": {"enabled": True, "burn": True, "font_size": 30,
                      "position": "bottom"},
        "scenes": scenes,
    }
