"""Subtitles and on-screen text.

Two outputs are produced from the scene plan:

1. A standard ``.srt`` sidecar file (for YouTube uploads / external players).
2. An ``.ass`` (libass) file used to BURN text into the video: captions,
   title cards, scene labels, and - mandatory for honesty - a
   "SYNTHETIC TEST FOOTAGE" watermark on every synthetic scene.

All times in the ASS file use the FINAL timeline (post-transition overlaps).
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from .config import ProjectConfig
from .scenes import ScenePlan
from .assets import parse_synthetic

MAX_LINE_CHARS = 42
MAX_LINES = 2


@dataclass
class Cue:
    start: float
    end: float
    text: str
    style: str = "Caption"

    def to_dict(self) -> dict:
        return {"start": round(self.start, 3), "end": round(self.end, 3),
                "style": self.style, "text": self.text}


def chunk_text(text: str, max_chars: int = MAX_LINE_CHARS,
               max_lines: int = MAX_LINES) -> List[str]:
    """Split text into cue-sized chunks (<= max_lines lines of <= max_chars)."""
    words = text.split()
    if not words:
        return []
    chunk_limit = max_chars * max_lines
    chunks: List[str] = []
    cur: List[str] = []
    cur_len = 0
    for w in words:
        extra = len(w) + (1 if cur else 0)
        if cur and cur_len + extra > chunk_limit:
            chunks.append(" ".join(cur))
            cur, cur_len = [w], len(w)
        else:
            cur.append(w)
            cur_len += extra
    if cur:
        chunks.append(" ".join(cur))
    return chunks


def wrap_lines(text: str, max_chars: int = MAX_LINE_CHARS) -> str:
    """Wrap a cue's text into <=2 display lines using ASS \\N."""
    words = text.split()
    lines: List[str] = []
    cur = ""
    for w in words:
        cand = (cur + " " + w).strip()
        if len(cand) > max_chars and cur:
            lines.append(cur)
            cur = w
        else:
            cur = cand
    if cur:
        lines.append(cur)
    return "\\N".join(lines[:MAX_LINES])


def build_caption_cues(plan: ScenePlan, cfg: ProjectConfig) -> List[Cue]:
    """Caption cues per scene, distributed across the scene's duration."""
    cues: List[Cue] = []
    for sc in plan.scenes:
        text = (sc.subtitle or sc.narration).strip()
        if not text or not cfg.subtitles.enabled:
            continue
        start = sc.final_start + 0.15
        end = sc.final_start + sc.duration - 0.20
        if end - start < 0.4:
            end = start + 0.4
        chunks = chunk_text(text)
        if not chunks:
            continue
        total_chars = sum(len(c) for c in chunks) or 1
        t = start
        span = max(0.4, end - start)
        for c in chunks:
            dur = span * len(c) / total_chars
            cues.append(Cue(t, min(t + dur, end), c))
            t += dur
    return cues


def build_overlay_events(plan: ScenePlan, cfg: ProjectConfig) -> List[Cue]:
    """All burn-in events in final-timeline order (captions, titles, labels,
    synthetic watermarks)."""
    events: List[Cue] = build_caption_cues(plan, cfg)
    for sc in plan.scenes:
        start, end = sc.final_start, sc.final_start + sc.duration
        if parse_synthetic(sc.source) is not None:
            events.append(Cue(start, end, "SYNTHETIC TEST FOOTAGE", style="Watermark"))
        if sc.title:
            if sc.title.startswith("TITLE:"):        # big centered title card
                events.append(Cue(start + 0.2, min(start + 2.6, end - 0.2),
                                  sc.title[len("TITLE:"):].strip(), style="Title"))
            else:
                events.append(Cue(start + 0.1, min(start + 1.8, end - 0.1),
                                  sc.title, style="SceneLabel"))
    events.sort(key=lambda c: (c.start, c.style != "Watermark"))
    return events


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------

def _srt_time(t: float) -> str:
    ms = int(round(t * 1000))
    h, rem = divmod(ms, 3600000)
    m, rem = divmod(rem, 60000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_srt(cues: List[Cue], path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for i, c in enumerate(cues, 1):
        lines.append(str(i))
        lines.append(f"{_srt_time(c.start)} --> {_srt_time(c.end)}")
        lines.append(c.text.replace("\\N", "\n"))
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def _ass_time(t: float) -> str:
    cs = int(round(t * 100))
    h, rem = divmod(cs, 360000)
    m, rem = divmod(rem, 6000)
    s, cs = divmod(rem, 100)
    return f"{h}:{m:02d}:{s:02d}.{cs:02d}"


def _hex_to_ass_bgr(color_hex: str, alpha_hex: str = "00") -> str:
    h = color_hex.lstrip("#")
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha_hex}{b}{g}{r}".upper()


_ASS_HEADER = """[Script Info]
; Generated by vidforge
ScriptType: v4.00+
PlayResX: {width}
PlayResY: {height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
"""

_STYLE_LINE = (
    "Style: {name},{fontname},{fontsize},{primary},{secondary},{outline},{back},"
    "{bold},0,0,0,100,100,0,0,1,{outline_w},{shadow},{align},{marginl},{marginr},"
    "{marginv},1\n"
)

_EVENTS_HEADER = """
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""


def write_ass(events: List[Cue], path: str | Path, width: int, height: int,
              cfg: Optional[ProjectConfig] = None,
              font_name: str = "DejaVu Sans") -> Path:
    """Write an .ass overlay file with styles sized for the target resolution."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    scale = max(width, height) / 720.0          # scale fonts with resolution
    caption_size = int((cfg.subtitles.font_size if cfg else 30) * scale)
    title_size = int(min(width, height) / 9)
    label_size = max(14, int(18 * scale))
    wm_size = max(13, int(16 * scale))

    position = cfg.subtitles.position if cfg else "bottom"
    if position == "top":
        cap_align, cap_marginv = 8, int(height * 0.06)
    elif position == "lower_third":
        cap_align, cap_marginv = 2, int(height * 0.30)
    else:  # bottom
        cap_align, cap_marginv = 2, int(height * 0.08)

    styles = {
        "Caption": dict(fontsize=caption_size, primary="&H00FFFFFF", secondary="&H00FFFFFF",
                        outline="&H00000000", back="&HA0000000", bold=-1,
                        outline_w=max(2, int(2 * scale)), shadow=1,
                        align=cap_align, marginl=30, marginr=30,
                        marginv=cap_marginv),
        "Title": dict(fontsize=title_size, primary="&H00FFFFFF", secondary="&H00FFFFFF",
                      outline="&H00202020", back="&H00000000", bold=-1,
                      outline_w=max(3, int(3 * scale)), shadow=2,
                      align=5, marginl=20, marginr=20, marginv=20),
        "SceneLabel": dict(fontsize=label_size, primary="&H00E8E8E8", secondary="&H00E8E8E8",
                           outline="&H00000000", back="&H00000000", bold=0,
                           outline_w=max(1, int(1.4 * scale)), shadow=0,
                           align=7, marginl=int(width * 0.03),
                           marginr=10, marginv=int(height * 0.03)),
        "Watermark": dict(fontsize=wm_size, primary="&H20FFFFFF", secondary="&H20FFFFFF",
                          outline="&H70000000", back="&H00000000", bold=0,
                          outline_w=1, shadow=0,
                          align=9, marginl=10, marginr=int(width * 0.03),
                          marginv=int(height * 0.025)),
    }
    out = _ASS_HEADER.format(width=width, height=height)
    for name, st in styles.items():
        out += _STYLE_LINE.format(name=name, fontname=font_name, **st)
    out += _EVENTS_HEADER
    for ev in events:
        # Neutralize ASS override-tag injection from user/AI text: braces and
        # backslashes are the only characters that can start a control
        # sequence in ASS, so remove them before writing Dialogue lines.
        text = ev.text.replace("{", "(").replace("}", ")").replace("\\", "")
        if ev.style in ("Caption", "Title"):
            text = wrap_lines(text)
        text = text.replace("\n", "\\N")
        out += (f"Dialogue: 0,{_ass_time(ev.start)},{_ass_time(ev.end)},"
                f"{ev.style},,0,0,0,,{text}\n")
    path.write_text(out, encoding="utf-8")
    return path
