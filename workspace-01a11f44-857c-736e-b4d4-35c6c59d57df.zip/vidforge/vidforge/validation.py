"""Output verification: does the exported file actually match the request?"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from . import env


@dataclass
class CheckResult:
    name: str
    ok: bool
    detail: str = ""

    def to_dict(self) -> dict:
        return {"name": self.name, "ok": self.ok, "detail": self.detail}


@dataclass
class VerifyResult:
    path: Path
    checks: List[CheckResult] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return all(c.ok for c in self.checks)

    @property
    def failures(self) -> List[str]:
        return [f"{c.name}: {c.detail}" for c in self.checks if not c.ok]

    def to_dict(self) -> dict:
        return {"file": str(self.path), "ok": self.ok,
                "checks": [c.to_dict() for c in self.checks]}


def verify_output(path: str | Path, *, expected_duration: Optional[float] = None,
                  width: Optional[int] = None, height: Optional[int] = None,
                  fps: Optional[int] = None, expect_audio: bool = False,
                  duration_tolerance: float = 0.4,
                  caps: Optional[env.Caps] = None) -> VerifyResult:
    """Inspect an exported file and compare it against the request."""
    caps = caps or env.get_caps()
    path = Path(path)
    res = VerifyResult(path=path)

    # 1. exists and non-empty
    if not path.is_file():
        res.checks.append(CheckResult("exists", False, f"{path} does not exist"))
        return res
    size = path.stat().st_size
    res.checks.append(CheckResult(
        "exists", size > 1024,
        f"{size / 1024:.0f} KiB" if size > 1024 else f"suspiciously small ({size} bytes)",
    ))

    # 2. probe metadata
    info = env.probe_media(str(path), caps)
    if info is None:
        res.checks.append(CheckResult("probe", False, "ffmpeg/ffprobe could not open the file"))
        return res
    res.checks.append(CheckResult(
        "probe", True,
        f"via {info['probe_tool']}: {info.get('video_codec')}, "
        f"{info.get('width')}x{info.get('height')}",
    ))

    # 3. duration
    if expected_duration is not None:
        dur = info.get("duration")
        if dur is None:
            res.checks.append(CheckResult("duration", False, "no duration reported"))
        else:
            ok = abs(dur - expected_duration) <= duration_tolerance
            res.checks.append(CheckResult(
                "duration", ok,
                f"{dur:.2f}s vs expected {expected_duration:.2f}s "
                f"(tolerance {duration_tolerance:.2f}s)",
            ))

    # 4. resolution
    if width and height:
        ok = info.get("width") == width and info.get("height") == height
        res.checks.append(CheckResult(
            "resolution", ok,
            f"{info.get('width')}x{info.get('height')} vs expected {width}x{height}",
        ))
        if info.get("width") and info.get("height"):
            ratio = info["width"] / info["height"]
            res.checks.append(CheckResult(
                "aspect", True, f"DAR {ratio:.3f} ({'vertical' if ratio < 1 else 'landscape'})",
            ))

    # 5. fps
    if fps:
        got = info.get("fps")
        ok = got is not None and abs(got - fps) <= 1.0
        res.checks.append(CheckResult("fps", ok, f"{got} vs expected {fps}"))

    # 6. audio
    res.checks.append(CheckResult(
        "audio", info.get("has_audio") == expect_audio,
        f"audio stream {'present' if info.get('has_audio') else 'absent'} "
        f"({'expected' if expect_audio else 'not expected'})",
    ))

    # 7. full decode
    ok, err = env.decode_check(str(path), caps)
    res.checks.append(CheckResult("decodable", ok, err or "decoded fully without errors"))

    return res
