"""Command-line interface.

    python3 -m vidforge render   <config.json> [--out DIR] [--keep-temp] [--strict]
    python3 -m vidforge validate <config.json> [--strict]
    python3 -m vidforge plan     <config.json> [--json]
    python3 -m vidforge draft    <anime_reel|documentary> "<topic>" --duration S [--ai]
    python3 -m vidforge probe    <media-file>
    python3 -m vidforge caps
    python3 -m vidforge demo
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import env
from .config import CANONICAL_DURATIONS, DURATION_BOUNDS, load_config
from .render import render_project
from .scenes import build_plan


def _cmd_render(args) -> int:
    result = render_project(
        args.config, out_dir=args.out, keep_temp=args.keep_temp,
        strict=args.strict, dry_run=args.dry_run, quiet=args.quiet,
    )
    if result.dry_run:
        print("DRY RUN OK — config valid, assets present, plan built:")
        print(json.dumps(result.plan.to_dict(), indent=2))
        return 0
    if result.ok:
        print(f"\nOK  -> {result.output_path}")
        if result.srt_path:
            print(f"subs -> {result.srt_path}")
        print(f"report -> {result.report_path}")
        return 0
    print("\nFAILED:", file=sys.stderr)
    for e in result.errors:
        print(f"  - {e}", file=sys.stderr)
    for w in result.warnings:
        print(f"  (warning) {w}", file=sys.stderr)
    return 1


def _cmd_validate(args) -> int:
    try:
        cfg = load_config(args.config, strict=args.strict)
    except Exception as e:  # ConfigError, OSError, json errors
        print(f"INVALID: {e}", file=sys.stderr)
        return 1
    print(f"VALID: {cfg.project.name} ({cfg.project.type}, "
          f"{cfg.project.duration:g}s, {cfg.project.width}x{cfg.project.height}@{cfg.project.fps})")
    if cfg.warnings:
        print("warnings:")
        for w in cfg.warnings:
            print(f"  - {w}")
    return 0


def _cmd_plan(args) -> int:
    cfg = load_config(args.config)
    bpm = cfg.music.bpm
    plan = build_plan(cfg, bpm)
    if args.json:
        print(json.dumps(plan.to_dict(), indent=2))
    else:
        print(f"plan: {plan.total_frames} frames = {plan.total:.2f}s "
              f"(final {plan.final_total:.2f}s), {len(plan.scenes)} scene(s)")
        for s in plan.scenes:
            print(f"  [{s.index:2d}] {s.id:<16} start={s.final_start:7.2f} "
                  f"dur={s.duration:6.2f} src={s.source:<28} trans={s.transition_in}")
        for n in plan.notes:
            print(f"  note: {n}")
    return 0


def _cmd_draft(args) -> int:
    if args.ai:
        from .ai import get_provider, AIDisabledError
        try:
            provider = get_provider(args.provider or "openai_compat", args.model)
            data = provider.generate_script(args.topic, args.duration, args.type)
            data.setdefault("project", {})
            data["project"].setdefault("type", args.type)
            data["project"].setdefault("duration", args.duration)
            data["project"].setdefault("name", args.topic.lower().replace(" ", "_")[:30])
        except AIDisabledError as e:
            print(f"AI unavailable ({e}); falling back to offline template.",
                  file=sys.stderr)
            data = None
        if data is not None:
            print(json.dumps(data, indent=2, ensure_ascii=False))
            return 0
    from .ai import draft_project_offline
    data = draft_project_offline(args.type, args.topic, args.duration)
    print(json.dumps(data, indent=2, ensure_ascii=False))
    print("# (offline template draft — edit scenes/subtitles before rendering)",
          file=sys.stderr)
    return 0


def _cmd_probe(args) -> int:
    caps = env.get_caps()
    info = env.probe_media(args.file, caps)
    if info is None:
        print(f"Cannot probe {args.file} (missing or not a media file)",
              file=sys.stderr)
        return 1
    print(json.dumps(info, indent=2))
    return 0


def _cmd_caps(args) -> int:
    try:
        caps = env.get_caps()
    except env.ToolError as e:
        print(f"{e}", file=sys.stderr)
        return 1
    print(json.dumps(caps.summary(), indent=2))
    return 0


def _cmd_demo(args) -> int:
    root = Path(__file__).resolve().parent.parent
    targets = [
        root / "examples" / "anime_reel_15s.json",
        root / "examples" / "documentary_30s.json",
    ]
    rc = 0
    for t in targets:
        if not t.is_file():
            print(f"missing example config: {t}", file=sys.stderr)
            rc = 1
            continue
        print(f"\n=== demo: {t.name} ===")
        rc |= _cmd_render(argparse.Namespace(
            config=str(t), out=None, keep_temp=False, strict=False,
            dry_run=False, quiet=False))
    return rc


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="vidforge",
        description="Lightweight, AI-optional video production pipeline.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    pr = sub.add_parser("render", help="end-to-end: config -> MP4 + report")
    pr.add_argument("config")
    pr.add_argument("--out", help="output directory (default: ./out/<name>)")
    pr.add_argument("--keep-temp", action="store_true",
                    help="keep intermediate scene/segment files")
    pr.add_argument("--strict", action="store_true",
                    help="treat config warnings as errors")
    pr.add_argument("--dry-run", action="store_true",
                    help="validate + build plan, do not render")
    pr.add_argument("--quiet", action="store_true")
    pr.set_defaults(fn=_cmd_render)

    pv = sub.add_parser("validate", help="validate a config file")
    pv.add_argument("config")
    pv.add_argument("--strict", action="store_true")
    pv.set_defaults(fn=_cmd_validate)

    pp = sub.add_parser("plan", help="show the computed scene plan")
    pp.add_argument("config")
    pp.add_argument("--json", action="store_true")
    pp.set_defaults(fn=_cmd_plan)

    pd = sub.add_parser("draft", help="scaffold a new project config")
    pd.add_argument("type", choices=["anime_reel", "documentary"])
    pd.add_argument("topic")
    pd.add_argument("--duration", type=float, required=True,
                    help=f"seconds; canonical: {CANONICAL_DURATIONS}")
    pd.add_argument("--ai", action="store_true",
                    help="use the configured AI provider (offline template otherwise)")
    pd.add_argument("--provider", default="openai_compat")
    pd.add_argument("--model", default="")
    pd.set_defaults(fn=_cmd_draft)

    pb = sub.add_parser("probe", help="inspect a media file")
    pb.add_argument("file")
    pb.set_defaults(fn=_cmd_probe)

    pc = sub.add_parser("caps", help="show ffmpeg/tool capabilities")
    pc.set_defaults(fn=_cmd_caps)

    dm = sub.add_parser("demo", help="render both bundled example projects")
    dm.set_defaults(fn=_cmd_demo)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.fn(args)
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        return 130


if __name__ == "__main__":
    sys.exit(main())
