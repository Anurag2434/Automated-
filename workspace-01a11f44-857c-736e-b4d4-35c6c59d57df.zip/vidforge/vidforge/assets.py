"""Source asset resolution and pre-flight checks."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

from . import env
from .config import ProjectConfig
from .scenes import ScenePlan

VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi"}
IMAGE_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".bmp"}
AUDIO_EXTS = {".wav", ".mp3", ".m4a", ".ogg", ".flac", ".aac", ".opus"}


class AssetError(RuntimeError):
    """Raised when a required source asset is missing or unusable."""


@dataclass
class SourceSpec:
    kind: str            # "synthetic" | "image" | "video"
    path: Optional[str]  # None for synthetic
    label: str           # short human description for reports


def parse_synthetic(source: str) -> Optional[str]:
    """Return the synthetic label if `source` is a synthetic URI, else None."""
    if source == "synthetic":
        return "synthetic"
    if source.startswith("synthetic:"):
        return source.split(":", 1)[1] or "synthetic"
    return None


def resolve_source(scene_source: str, cfg: ProjectConfig) -> SourceSpec:
    """Resolve a scene `source` string into a SourceSpec.

    Raises AssetError with the list of attempted paths when a file source
    cannot be found.
    """
    label = parse_synthetic(scene_source)
    if label is not None:
        return SourceSpec(kind="synthetic", path=None, label=label)

    p = Path(scene_source)
    tried: List[str] = []
    if p.is_absolute():
        candidates = [p]
    else:
        cfg_dir = cfg.path.resolve().parent
        candidates = [
            cfg_dir / p,
            cfg_dir / cfg.project.assets_dir / p,
        ]
    for cand in candidates:
        tried.append(str(cand))
        if cand.is_file():
            ext = cand.suffix.lower()
            if ext in VIDEO_EXTS:
                return SourceSpec(kind="video", path=str(cand),
                                  label=f"video:{cand.name}")
            if ext in IMAGE_EXTS:
                return SourceSpec(kind="image", path=str(cand),
                                  label=f"image:{cand.name}")
            raise AssetError(
                f"Source '{scene_source}' has unsupported extension '{ext}'. "
                f"Supported: video {sorted(VIDEO_EXTS)}, image {sorted(IMAGE_EXTS)}."
            )
    raise AssetError(
        f"Source asset '{scene_source}' not found. Tried: "
        + ", ".join(tried)
        + ". Put files next to the config (or in the assets_dir) or use "
        "'synthetic' as the source."
    )


def resolve_audio_source(source: str, cfg: ProjectConfig) -> Path:
    """Resolve a music/audio source path (accepts audio file extensions).

    Raises AssetError when the file is missing or not an audio type.
    """
    p = Path(source)
    tried: List[str] = []
    if p.is_absolute():
        candidates = [p]
    else:
        cfg_dir = cfg.path.resolve().parent
        candidates = [cfg_dir / p, cfg_dir / cfg.project.assets_dir / p]
    for cand in candidates:
        tried.append(str(cand))
        if cand.is_file():
            if cand.suffix.lower() in AUDIO_EXTS:
                return cand
            raise AssetError(
                f"Audio source '{source}' has unsupported extension "
                f"'{cand.suffix}' (supported: {sorted(AUDIO_EXTS)})."
            )
    raise AssetError(
        f"Audio source '{source}' not found. Tried: " + ", ".join(tried)
    )


def check_assets(cfg: ProjectConfig, plan: ScenePlan) -> dict:
    """Validate every scene source before rendering.

    Returns a report dict. Raises AssetError listing ALL missing/invalid
    sources at once (more useful than failing on the first).
    """
    caps = env.get_caps()
    statuses = []
    errors: List[str] = []
    for sc in plan.scenes:
        entry = {"scene": sc.id, "source": sc.source}
        try:
            spec = resolve_source(sc.source, cfg)
            entry.update(kind=spec.kind, label=spec.label, ok=True)
            if spec.kind == "video":
                info = env.probe_media(spec.path, caps)
                if info is None:
                    raise AssetError(f"cannot open/decode '{spec.path}' with ffmpeg")
                entry["asset_duration"] = info.get("duration")
                if info.get("duration") and sc.duration > info["duration"] + 0.05:
                    entry["note"] = (
                        f"asset is {info['duration']:.2f}s, scene needs "
                        f"{sc.duration:.2f}s -> will loop the clip"
                    )
            elif spec.kind == "image":
                info = env.probe_media(spec.path, caps)
                if info is None:
                    raise AssetError(f"cannot open image '{spec.path}'")
                entry["asset_resolution"] = f"{info.get('width')}x{info.get('height')}"
        except AssetError as e:
            errors.append(f"Scene '{sc.id}': {e}")
            entry.update(kind="error", ok=False, error=str(e))
        statuses.append(entry)

    if errors:
        raise AssetError(
            f"{len(errors)} asset problem(s): " + " | ".join(errors)
        )
    return {"scenes": statuses, "all_ok": True}


def find_narration_file(cfg: ProjectConfig, scene_id: str) -> Optional[Path]:
    """Look for <narration_dir>/<scene_id>.<audio-ext> next to the config."""
    cfg_dir = cfg.path.resolve().parent
    base = cfg_dir / cfg.narration.dir
    for ext in sorted(AUDIO_EXTS):
        cand = base / f"{scene_id}{ext}"
        if cand.is_file():
            return cand
    return None
